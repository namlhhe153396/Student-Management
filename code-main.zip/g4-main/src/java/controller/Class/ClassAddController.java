/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.Class;

import dao.ClassDao;
import dao.SubjectDao;
import dao.UserDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Subject;
import model.User;
import model.Class;

/**
 *
 * @author ASUS
 */
@WebServlet(name = "ClassAddController", urlPatterns = {"/classAdd"})
public class ClassAddController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            UserDao daoUser = new UserDao();
            SubjectDao daoSub = new SubjectDao();
            ClassDao dao = new ClassDao();

            List<User> listUser = daoUser.getAllUser();
            List<Subject> listSub = daoSub.getAllSubject();

            request.setAttribute("listUser", listUser);
            request.setAttribute("listSub", listSub);
            RequestDispatcher dispath
                    = request.getRequestDispatcher("View/ClassAdd.jsp");
            //run 
            dispath.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //get and getData
        String class_id = request.getParameter("class_id");
        String class_code = request.getParameter("class_code");
        String trainer_id = request.getParameter("trainer_id");
        String subject_id = request.getParameter("subject_id");
        String class_year = request.getParameter("class_year");
        String class_term = request.getParameter("class_term");
        String block5_class = request.getParameter("block5_class");
        String status = request.getParameter("status");

        ClassDao dao = new ClassDao();
        UserDao daoUser = new UserDao();
        SubjectDao daoSub = new SubjectDao();
        int warring = 0;
        List<User> listUser = daoUser.getAllUser();
        List<Subject> listSub = daoSub.getAllSubject();
        String regex = "^[A-Za-z0-9]{1,9}+$";

        if (class_code == null || class_code.equals("")) {
            request.setAttribute("messWarring1", "!! Class Code not null !!");
            warring = 1;
        } else if (class_code.length() > 6) {
            request.setAttribute("messWarring1", "!! Class Code not more than 6 !!");
            warring = 1;
        } else if (!class_code.matches(regex)) {
            request.setAttribute("messWarring1", "!! Class Code not have special characters [@,!,#,$,..] !!");
            warring = 1;
        }

        if (trainer_id == null || trainer_id.equals("")) {
            request.setAttribute("messWarring2", "!! Trainer ID not null !!");
            warring = 1;
        } else if (trainer_id.length() > 8) {
            request.setAttribute("messWarring2", "!! Trainer ID not more than 8 !!");
            warring = 1;
        }
        
        if (subject_id == null || subject_id.equals("")) {
            request.setAttribute("messWarring3", "!! Subject ID not null !!");
            warring = 1;
        } else if (subject_id.length() > 6) {
            request.setAttribute("messWarring3", "!! Subject ID not more than 6 !!");
            warring = 1;
        }

        if (class_year == null || class_year.equals("")) {
            request.setAttribute("messWarring4", "!! Year not null !!");
            warring = 1;
        } else if (class_year.length() > 7) {
            request.setAttribute("messWarring4", "!! Year not more than 7 !!");
            warring = 1;
        } else if (!class_year.matches(regex)) {
            request.setAttribute("messWarring4", "!! Year not have special characters [@,!,#,$,..] !!");
            warring = 1;
        }

        if (class_term == null || class_term.equals("")) {
            request.setAttribute("messWarring5", "!! Class Term not null !!");
            warring = 1;
        } else if (class_term.length() > 9) {
            request.setAttribute("messWarring5", "!! Class Term not more than 9 !!");
            warring = 1;
        } else if (!class_year.matches(regex)) {
            request.setAttribute("messWarring5", "!! Class Term not have special characters [@,!,#,$,..] !!");
            warring = 1;
        }

        if (warring == 1) {
            request.setAttribute("class_id", class_id);
            request.setAttribute("class_code", class_code);
            request.setAttribute("class_year", class_year);
            request.setAttribute("class_term", class_term);
            request.setAttribute("class_year", class_year);
            request.setAttribute("listUser", listUser);
            request.setAttribute("listSub", listSub);
            RequestDispatcher dispath
                    = request.getRequestDispatcher("./ClassAdd.jsp");
            //run 
            dispath.forward(request, response);
        } else {
            dao.addClass(class_code, trainer_id, subject_id, class_year, class_term, block5_class, status);
            response.sendRedirect("classList");
        }

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
