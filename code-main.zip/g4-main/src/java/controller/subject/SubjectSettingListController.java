/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.subject;

import dao.AdminDao;
import dao.SubjectDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Subject;
import model.SubjectSetting;
import model.User;

/**
 *
 * @author 84337
 */
@WebServlet(name = "SubjectSettingListController", urlPatterns = {"/subjectsettinglist"})
public class SubjectSettingListController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try ( PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String action = request.getParameter("action");
            AdminDao dao = new AdminDao();
            SubjectDao sd = new SubjectDao();
            SubjectSetting ss = new SubjectSetting();
            String indexPage = request.getParameter("index");
            String txtSearch = request.getParameter("search");
            List<Subject> listSubject = new ArrayList<>();
            listSubject = sd.getAllSubject();

            HttpSession session = request.getSession();
            User u = (User) session.getAttribute("acc");
            List<SubjectSetting> list = new ArrayList<>();
            if (u.getRollId() == 0) {
                try {

                    if (txtSearch == null || txtSearch.equals("")) {
                        list = dao.getAllSubjectSetting();
                    } else {
                        list = sd.searchSS(txtSearch);
                    }

                    if (action != null) {

                        if ((action.equals("change"))) {
                            String id = request.getParameter("id");

                            try {
                                System.out.println(id);
                                SubjectSetting statusNow = sd.getSubjectSettingByID(id);
                                System.out.println(statusNow);
                                sd.changeStatusSubjectSetting(statusNow.getStatus(), id);

                            } catch (Exception e) {
                                System.out.println(e);
                            }
                            list = dao.getAllSubjectSetting();
                            System.out.println(list);
                        }
                        if ((action.equals("status1"))) {
                            list = sd.SubjectSettingByStatus1();
                        }
                        if ((action.equals("status0"))) {
                            list = sd.SubjectSettingByStatus0();
                        }
                        if ((action.equals("subject"))) {
                            String sid = request.getParameter("sid");
                            list = sd.SubjectSettingBySubject(sid);
                        }
                        if ((action.equals("sortdescbySubject"))) {
                            list = dao.SortSubjectbyNameDESC();//                    
                        }
                        if ((action.equals("sortascbySubject"))) {
                            list = dao.SortSubjectbyNameASC();//                    
                        }
                        if ((action.equals("sortDescByType"))) {
                            list = dao.SortSubjectbyTypeDESC();//                    
                        }
                        if ((action.equals("sortAscByType"))) {
                            list = dao.SortSubjectbyTypeASC();//                    
                        }
                        if ((action.equals("sortTitleDesc"))) {
                            list = dao.SortSubjectbyTitleDESC();//                    
                        }
                        if ((action.equals("sortTitleAsc"))) {
                            list = dao.SortSubjectbyTitleASC();//                    
                        }
                        if ((action.equals("sortascbyValue"))) {
                            list = dao.SortSubjectbyValueASC();//                    
                        }
                        if ((action.equals("sortdescbyValue"))) {
                            list = dao.SortSubjectbyValueDESC();//                    
                        }

                    }
                    int page = 1;
                    String page_size = request.getParameter("page");
                    if (page_size != null) {
                        page = Integer.parseInt(page_size);
                    }
                    int size = list.size() / 10;
                    if (list.size() > (10 * size)) {
                        size += 1;
                    }
                    int end;
                    if (page * 10 > list.size()) {
                        end = list.size();
                    } else {
                        end = page * 10;
                    }
                    //.subList((page-1)*10, page*10)
                    request.setAttribute("size", size);
                    request.setAttribute("txtSearch", txtSearch);

                    request.setAttribute("list", list.subList((page - 1) * 10, end));
                } catch (Exception e) {
                    System.out.println("Dcmm" + e);
                }
                    

            } else if (u.getRollId() == 1) {

                {

                    if (txtSearch == null || txtSearch.equals("")) {
                        list = dao.getAllSubjectSettingForAuthor(u.getUserID());
                    } else {
                        list = sd.searchSSForAuth(u.getUserID(), txtSearch);
                    }

                    if (action != null) {

                        if ((action.equals("change"))) {
                            String id = request.getParameter("id");

                            try {
                                SubjectSetting statusNow = sd.getSubjectSettingByID(id);
                                sd.changeStatusSubjectSetting(statusNow.getStatus(), id);

                            } catch (Exception e) {
                                System.out.println(e);
                            }
                            list = dao.getAllSubjectSettingForAuthor(u.getUserID());
                            System.out.println(list);
                        }
                        if ((action.equals("status1"))) {
                            list = sd.SubjectSettingByStatus1ForAuth(u.getUserID());
                        }
                        if ((action.equals("status0"))) {
                            list = sd.SubjectSettingByStatus0ForAth(u.getUserID());
                        }
                        if ((action.equals("subject"))) {
                            String sid = request.getParameter("sid");
                            list = sd.SubjectSettingBySubjectForAuth(sid, u.getUserID());
                        }
                        if ((action.equals("sortdescbySubject"))) {
                            list = dao.SortSubjectbyNameDESCForA(u.getUserID());//                    
                        }
                        if ((action.equals("sortascbySubject"))) {
                            list = dao.SortSubjectbyNameASCForA(u.getUserID());//         
                        }
                        if ((action.equals("sortDescByType"))) {
                            list = dao.SortSubjectbyTypeDESCForA(u.getUserID());//            
                        }
                        if ((action.equals("sortAscByType"))) {
                            list = dao.SortSubjectbyTypeASCForA(u.getUserID());//        
                        }
                        if ((action.equals("sortTitleDesc"))) {
                            list = dao.SortSubjectbyTitleDESCForA(u.getUserID());//             
                        }
                        if ((action.equals("sortTitleAsc"))) {
                            list = dao.SortSubjectbyTitleASCForA(u.getUserID());//                
                        }
                        if ((action.equals("sortascbyValue"))) {
                            list = dao.SortSubjectbyValueASCForA(u.getUserID());//            
                        }
                        if ((action.equals("sortdescbyValue"))) {
                            list = dao.SortSubjectbyValueDESCForA(u.getUserID());//          
                        }

                    }
                    int page = 1;
                    String page_size = request.getParameter("page");
                    if (page_size != null) {
                        page = Integer.parseInt(page_size);
                    }
                    int size = list.size() / 10;
                    if (list.size() > (10 * size)) {
                        size += 1;
                    }
                    int end;
                    if (page * 10 > list.size()) {
                        end = list.size();
                    } else {
                        end = page * 10;
                    }
                    //.subList((page-1)*10, page*10)
                    request.setAttribute("size", size);
                    request.setAttribute("txtSearch", txtSearch);

                    request.setAttribute("list", list.subList((page - 1) * 10, end));
                }

            }
            request.setAttribute("listSubject", listSubject);
            request.getRequestDispatcher("View/SubjectSettingList.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
