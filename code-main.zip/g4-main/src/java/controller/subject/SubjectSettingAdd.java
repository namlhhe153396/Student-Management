/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.subject;

import dao.AdminDao;
import dao.SubjectDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Setting;
import model.Subject;
import model.SubjectSetting;
import model.User;

/**
 *
 * @author ASUS
 */
@WebServlet(name = "SubjectSettingAdd", urlPatterns = {"/subjectSettingAdd"})
public class SubjectSettingAdd extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            SubjectDao daoSub = new SubjectDao();
            AdminDao dao = new AdminDao();
            String subjID = null;
            String setting_id = null;
            String status = null;
            List<Subject> listSub = daoSub.getAllSubject();
            List<Setting> listSt = dao.getAllSetting();

            request.setAttribute("status", status);
            request.setAttribute("setting_id", setting_id);
            request.setAttribute("subjID", subjID);
            request.setAttribute("listSt", listSt);
            request.setAttribute("listSub", listSub);
            RequestDispatcher dispath
                    = request.getRequestDispatcher("View/SubjectSettingAdd.jsp");
            //run 
            dispath.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        AdminDao dao = new AdminDao();
        SubjectDao daoSub = new SubjectDao();
        List<Setting> listSt = dao.getAllSetting();

//        SubjectSetting subS = dao.getSubjectSettingByID(subSid);
        int warring = 0;
        String inte = "[0-9]+";
        String regex = "^[A-Za-z0-9]{1,9}+$";
        String regex1 = "^[A-Za-z ]+$";
//        System.out.println(s.getId());
//        System.out.println("");
        String subjID = request.getParameter("sjID");
        String type = "";
        String typeId = "";
        String settingid = request.getParameter("setting_id");
        String title = request.getParameter("title");
        String order = request.getParameter("order");
        String value = request.getParameter("value");
        String status = request.getParameter("status");

        for (Setting setting : listSt) {
            if (setting.getId().equals(settingid)) {
                type = setting.getType();
            }
        }
        if (type.equals("Grade")) {
            typeId = "1";
        } else if (type.equals("Complexity")) {
            typeId = "2";
        }
        if (title == null || title.equals("")) {
            request.setAttribute("messWarring2", "!! Title not null !! ");
            warring = 1;
        } else if (!title.matches(regex1)) {
            request.setAttribute("messWarring2", "!! Title not have special characters [@,!,#,$,..] !!");
            warring = 1;
        }

        if (value == null || value.equals("")) {
            request.setAttribute("messWarring3", "!! Value not null !!");
            warring = 1;
        } else if (!value.matches(regex)) {
            request.setAttribute("messWarring3", "!! Value not have special characters [@,!,#,$,..] !!");
            warring = 1;
        }

        if (order == null || order.equals("")) {
            request.setAttribute("messWarring4", "!! Order not null !!");
            warring = 1;
        } else if (!order.matches(inte)) {
            warring = 1;
            request.setAttribute("messWarring4", "!! Order must be number !!");
        }

        if (warring == 1) {
            List<Subject> listSub = daoSub.getAllSubject();

            request.setAttribute("subjID", subjID);
            request.setAttribute("setting_id", settingid);
            request.setAttribute("title", title);
            request.setAttribute("order", order);
            request.setAttribute("value", value);
            request.setAttribute("status", status);
            request.setAttribute("listSt", listSt);
            request.setAttribute("listSub", listSub);

            RequestDispatcher dispath
                    = request.getRequestDispatcher("View/SubjectSettingAdd.jsp");
            //run 
            dispath.forward(request, response);

        } else {
            dao.addSubjectSetting(subjID, settingid, typeId, title, value, order, status);

            response.sendRedirect("subjectsettinglist");
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
