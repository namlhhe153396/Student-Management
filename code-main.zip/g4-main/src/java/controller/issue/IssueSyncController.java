/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.issue;

import dao.AdminDao;
import dao.SubjectDao;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
//import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
<<<<<<< HEAD:src/java/controller/IssueController.java
import javax.servlet.http.Part;
import model.ClassUser;
import model.Issues;
import model.Team;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
=======
import model.Issues;
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5:src/java/controller/issue/IssueSyncController.java

/**
 *
 * @author ASUS
 */
<<<<<<< HEAD:src/java/controller/IssueController.java
@MultipartConfig
@WebServlet(name = "IssueController", urlPatterns = {"/issuecontroller"})
public class IssueController extends HttpServlet {
=======
@WebServlet(name = "IssueSyncController", urlPatterns = {"/issueSync"})
public class IssueSyncController extends HttpServlet {
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5:src/java/controller/issue/IssueSyncController.java

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String action = request.getParameter("action");
            AdminDao dao = new AdminDao();
            SubjectDao sd = new SubjectDao();
            String txtSearch = request.getParameter("search");
//            ClassUser cu = new ClassUser();
            Issues i = new Issues();
            String tid = request.getParameter("tid");
            //lấy từ git về 
//            dao.syncIssuesGit("36006703", "glpat-spzc-6MZcxrvygH6_FC1");
            //update lại dữ liệu
            dao.syncIssuesGitCheckUpdate("36006703", "glpat-spzc-6MZcxrvygH6_FC1");
            List<Issues> list = new ArrayList<>();
            List<Team> listTeam = new ArrayList<>();
            listTeam = dao.getAllTeam();
            if (txtSearch == null || txtSearch.equals("")) {
                list = dao.getAllIssue();
            } else {
                list = sd.searchIssue(txtSearch);
            }

            if (action != null) {
                if ((action.equals("change"))) {
                    String id = request.getParameter("isid");

                    try {
                        sd.changeStatusIssue(id);
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                    list = dao.getAllIssue();
                    System.out.println(list);
                }

                if ((action.equals("status0"))) {
                    list = sd.IssueStatus0();
                }
                if ((action.equals("allstatus"))) {
                    list = sd.IssueAllStatus();
                }
                if ((action.equals("status1"))) {
                    list = sd.IssueStatus1();

                }
                if ((action.equals("team_id"))) {
                    list = sd.searchIssueTeam(tid);
                }
                if ((action.equals("sortascbyAssignee"))) {
                    list = dao.SortIssueAsscByAssignee();//                    
                }
                if ((action.equals("sortdescbyAssignee"))) {
                    list = dao.SortIssueDescByAssignee();//                    
                }
                if ((action.equals("sortdescbyteam"))) {
                    list = dao.SortIssueDescByTeam();
                }
                if ((action.equals("sortascbyteam"))) {
                    list = dao.SortIssueAscByTeam();
                }
                if ((action.equals("sortIssueTitleAsc"))) {
                    list = dao.sortIssueTitleAsc();
                }
                if ((action.equals("sortIssueTitleDesc"))) {
                    list = dao.sortIssueTitleDesc();
                }
                if ((action.equals("sortDueDateAsc"))) {
                    list = dao.sortDueDateAsc();
                }
                if ((action.equals("sortDueDateDesc"))) {
                    list = dao.sortDueDateDesc();
                }

                if ((action.equals("sortLableAsc"))) {
                    list = dao.sortLableAsc();
                }
                if ((action.equals("sortLableDesc"))) {
                    list = dao.sortLableDesc();
                }

                if ((action.equals("ImportIssue2Excel"))) {

                    ServletContext servletContext = this.getServletConfig().getServletContext();
                    File repository = (File) servletContext.getAttribute("javax.servlet.context.tempdir");
//        ServletConfig sc = getServletConfig();
                    String path = servletContext.getRealPath("/Excel");

                    Part filePart = request.getPart("file");

                    String fileName = filePart.getSubmittedFileName();
//                    String a = fileName.substring(fileName.length() - 4, fileName.length());

//                        String haha = "đỉk cuj maky";
//                        list = dao.getAllIssue();
//
//                        request.setAttribute("j", haha);
//                        request.getRequestDispatcher("IssueList.jsp").forward(request, response);
                    InputStream is = filePart.getInputStream();

                    Files.copy(is, Paths.get(path + "/" + fileName),
                            StandardCopyOption.REPLACE_EXISTING);
                    File file = new File(path + "/" + fileName);
                    try {
                        FileInputStream inp = new FileInputStream(file);
                        XSSFWorkbook wb = new XSSFWorkbook(inp);
//                        request.setAttribute("a", path);
                        Sheet sheet = wb.getSheetAt(0);
//                         FormulaEvaluator formula =wb.getCreationHelper().createFormulaEvaluator();
                        for (int j = 1; j <= sheet.getLastRowNum(); j++) {

                            Row row = sheet.getRow(j);
                            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                            java.util.Date d = row.getCell(5).getDateCellValue();
                            java.util.Date d2 = row.getCell(6).getDateCellValue();
                            String assignee_id = row.getCell(0).getStringCellValue();
                            String issue_title = row.getCell(1).getStringCellValue();
                            String description = row.getCell(2).getStringCellValue();
                            int gitlab_id = (int) row.getCell(3).getNumericCellValue();
                            String gitlab_url = row.getCell(4).getStringCellValue();
                            String created_date = df.format(d);
                            String due_date = df.format(d2);
                            int team_id = (int) row.getCell(7).getNumericCellValue();
                            int milestone_id = (int) row.getCell(8).getNumericCellValue();
                            int function_ids = (int) row.getCell(9).getNumericCellValue();
                            String labels = row.getCell(10).getStringCellValue();
                            int status = (int) row.getCell(11).getNumericCellValue();
//                            System.out.println(assignee_id);
                            dao.addIssue(assignee_id, issue_title, description, gitlab_id, gitlab_url, created_date, due_date, team_id, milestone_id, function_ids, labels, status);
                        }
//                            int rowIndex = 0;
//                        writeHeader(sheet, rowIndex);
                    } catch (Exception e) {
                        System.out.println(e);
                    }

                }
//                request.getRequestDispatcher("hshs")
//                request.getRequestDispatcher("IssueList.jsp").forward(request, response);

<<<<<<< HEAD:src/java/controller/IssueController.java
//                
=======
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5:src/java/controller/issue/IssueSyncController.java
            }

//                    response.setContentType("application/vnd.ms-excel");
//                    
            int page = 1;
            String page_size = request.getParameter("page");
            if (page_size != null) {
                page = Integer.parseInt(page_size);
            }
            int size = list.size() / 10;
            if (list.size() > (10 * size)) {
                size += 1;
            }
            int end;
            if (page * 10 > list.size()) {
                end = list.size();
            } else {
                end = page * 10;
            }
            //.subList((page-1)*10, page*10)
            request.setAttribute("size", size);
            request.setAttribute("txtSearch", txtSearch);
            request.setAttribute("listT", list.subList((page - 1) * 10, end));
            request.setAttribute("list", i);
            request.setAttribute("listTeam", listTeam);
<<<<<<< HEAD:src/java/controller/IssueController.java
            request.getRequestDispatcher("IssueList.jsp").forward(request, response);
        }

    }

    public static void main(String[] args) {
        AdminDao dao = new AdminDao();
        ClassUser cu = new ClassUser();
        SubjectDao sd = new SubjectDao();
//        cu = sd.getClassUserByID("4");
//        System.out.println(cu);
//
        List<Team> list = dao.getAllTeam();
        for (Team o : list) {
            System.out.println(o);
=======
            request.getRequestDispatcher("View/IssueList.jsp").forward(request, response);
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5:src/java/controller/issue/IssueSyncController.java
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
