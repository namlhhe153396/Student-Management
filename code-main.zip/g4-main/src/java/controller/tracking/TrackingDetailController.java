/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tracking;

import dao.MilestoneDao;
import dao.TrackingDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Function;
import model.Iteration;
import model.Milestone;
import model.Team;
import model.Tracking;

/**
 *
 * @author NamOK
 */
public class TrackingDetailController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            TrackingDAO dao = new TrackingDAO();
            String trackingid = (String) request.getParameter("id");
            Tracking tra = new Tracking();
            //int miid = dao.lastid() + 1;
            //................................
            //all team , function , milestone 
            List<Team> listT = new ArrayList();
            listT = dao.getAllTeam();
            List<Function> listF = new ArrayList();
            listF = dao.getAllFunction();
            List<Milestone> listM = new ArrayList();
            listM = dao.getAllMilestone();
            //............................
            if (trackingid != null) {

                int id = Integer.parseInt(trackingid);
                try {
                    tra = dao.GetTrackingbyID(id);
                    //............................
                    int traid = tra.getTracking_id();
                    String name = tra.getTracking_name();
                    //........................................
                    listT.add(0, new Team(tra.getTeam_id(), tra.getTeam_name()));
                    listF.add(0, new Function(tra.getFunction_id(), tra.getFunction_name()));
                    listM.add(0, new Milestone(tra.getMilestone_id(), tra.getMilestone_name()));
                    //.........................................
                    request.setAttribute("trackingname", name);
                    request.setAttribute("trackingid", tra.getTracking_id());
                    request.setAttribute("tra", tra);

                } catch (Exception e) {
                    System.out.println(e);
                }

            }

            //..................................
            request.setAttribute("listT", listT);
            request.setAttribute("listF", listF);
            request.setAttribute("listM", listM);
            request.getRequestDispatcher("View/trackingdetail.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TrackingDAO dao = new TrackingDAO();
        //...............................
        int tracking_id, team_id, milestone_id, function_id, assigner_id, assignee_id, status;
        String tracking_note, updates, message;
        //.....................................
        tracking_id = Integer.parseInt((String) request.getParameter("trackingid"));
        team_id = Integer.parseInt((String) request.getParameter("teamid"));
        milestone_id = Integer.parseInt((String) request.getParameter("milesid"));
        function_id = Integer.parseInt((String) request.getParameter("funid"));
        assigner_id = Integer.parseInt((String) request.getParameter("Assigner"));
        assignee_id = Integer.parseInt((String) request.getParameter("Assignee"));
        status = 1;
        tracking_note = (String) request.getParameter("note");
        updates = "";
        message = request.getParameter("message");

        Tracking tra = new Tracking(tracking_id, team_id, milestone_id, function_id, assigner_id, assignee_id, tracking_note, updates, status);
        try {
            tra = dao.GetTrackingbyID(tra.getTracking_id()) ;
        } catch (Exception ex) {
            Logger.getLogger(TrackingDetailController.class.getName()).log(Level.SEVERE, null, ex);
        }
        tra.setStatus(status);
//        if (message == null) {
//            dao.updateTracking(mi);
        request.setAttribute("su", "Successfully !");
//        }
        request.setAttribute("trackingname", tra.getTracking_name());
        request.setAttribute("tra", tra);
        //...........................................
        //all team , function , milestone 
        List<Team> listT = new ArrayList();
        listT = dao.getAllTeam();
        List<Function> listF = new ArrayList();
        listF = dao.getAllFunction();
        List<Milestone> listM = new ArrayList();
        listM = dao.getAllMilestone();
        listT.add(0, new Team(tra.getTeam_id(), tra.getTeam_name()));
        listF.add(0, new Function(tra.getFunction_id(), tra.getFunction_name()));
        listM.add(0, new Milestone(tra.getMilestone_id(), tra.getMilestone_name()));
        //..................................
        request.setAttribute("listT", listT);
        request.setAttribute("listF", listF);
        request.setAttribute("listM", listM);
        //...................................
        request.getRequestDispatcher("trackingdetail.jsp").forward(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
