/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller.tracking;

import model.Function;
import dao.MilestoneDao;
import dao.TrackingDAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Milestone;
import model.Team;
import model.Tracking;

/**
 *
 * @author NamOK
 */
public class TrackingController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            TrackingDAO dao = new TrackingDAO();
            List<Tracking> list = new ArrayList();
            MilestoneDao mdao = new MilestoneDao();

            String action = request.getParameter("action");
            //...........................
            //..........action          
            if (action != null) {
                if ((action.equals("search"))) {
                    String status, from, to, teamid, milestone_id, function_id;
                    String str = "";
                    int role = 0;
                    from = request.getParameter("from");
                    to = request.getParameter("to");
                    teamid = request.getParameter("teamid");
                    milestone_id = request.getParameter("milestone_id");
                    function_id = request.getParameter("function_id");
                    status = request.getParameter("status");
                    if (teamid != null && !teamid.isEmpty()) {
                        int num = Integer.parseInt(teamid);
                        str = "  and tracking.team_id =" + num;
                        try {
                            list = dao.getTrackingbyString(str);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    } else if (milestone_id != null && !milestone_id.isEmpty()) {
                        int num = Integer.parseInt(milestone_id);
                        str = " and tracking.milestone_id =" + num;
                        try {
                            list = dao.getTrackingbyString(str);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    } else if (function_id != null && !function_id.isEmpty()) {
                 
                        int num = Integer.parseInt(function_id);
                        str = " and tracking.function_id =" + num;
                        try {
                            list = dao.getTrackingbyString(str);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    } else if (status != null && !status.isEmpty()) {
                        //function_id
                        int num = Integer.parseInt(status);
                        str = " and tracking.status =" + num;
                        try {
                            list = dao.getTrackingbyString(str);
                        } catch (Exception e) {
                            System.out.println(e);
                        }
                    } else {
                        list = dao.getAllTrackings();
                    }

                }
//                //.....Change status 
//                if ((action.equals("change"))) {
//                    String id = request.getParameter("id");
//                    try {
//                        dao.changeStatus(id);
//                    } catch (Exception e) {
//                        System.out.println(e);
//                    }
//                    listM = mdao.getAllMilestone();
//                    request.setAttribute("byClass", "All Class");
//                    request.setAttribute("byIter", "All Iteration");
//                }
                //........................
                //......Sort......................
                if ((action.equals("sort"))) {
                    String table = request.getParameter("table");
                    int inco = Integer.parseInt((String) request.getParameter("inco"));
                    String by = "";
                    if (inco == 1) {
                        by = " asc ";
                    } else {
                        by = " desc ";
                    }
                    String str = table + by;
                    list = dao.getAllTrackingSort(str);
                }
                //...........................

            } else {
                list = dao.getAllTrackings();
//                for (Milestone i : list) {
//                    System.out.println(i.getClass_id());
//                }

            }
//...............................
//            list = dao.getAllMilestone();
//            for(Milestone i : list)
//                    System.out.println(i.getClass_id());
            //..................................
            request.setAttribute("byTeam", "All Team");
            List<Team> listT = new ArrayList();
            listT = dao.getAllTeam();
            request.setAttribute("listTeam", listT);
            //..................................
            request.setAttribute("byMilestone", "All Milestone");
            List<Milestone> listM = new ArrayList();
            listM = dao.getAllMilestone();
            request.setAttribute("listM", listM);
            //..................................
            request.setAttribute("byFunction", "All Function");
            List<Function> listF = new ArrayList();
            listF = dao.getAllFunction();
            request.setAttribute("listF", listF);
//            //...........................
            request.setAttribute("byStatus", "All Status");

//            list = dao.getAllTracking();
//            System.out.println(list.get(0));
            //...........................
            int page = 1;
            String page_size = request.getParameter("page");
            if (page_size != null) {
                page = Integer.parseInt(page_size);
            }
            int size = list.size() / 10;
            if (list.size() > (10 * size)) {
                size += 1;
            }
            int end;
            if (page * 10 > list.size()) {
                end = list.size();
            } else {
                end = page * 10;
            }
            //.subList((page-1)*10, page*10)
            request.setAttribute("size", size);
            request.setAttribute("listT", list);
            request.getRequestDispatcher("View/trackinglist.jsp").forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
