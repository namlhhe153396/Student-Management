/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller.classUser;

import dao.AdminDao;
import dao.ClassUserDAO;
import dao.UserDao;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ClassUser;
import model.Team;
import model.User;

/**
 *
 * @author 84337
 */
@WebServlet(name = "ClassUserAdd", urlPatterns = {"/classuseradd", "/add"})
public class ClassUserAdd extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        try ( PrintWriter out = response.getWriter()) {

            UserDao udao = new UserDao();
            ClassUserDAO cud = new ClassUserDAO();
            AdminDao dao = new AdminDao();
            ClassUser cu = new ClassUser();
            cu = cud.getClassUserByID("1");
            List<ClassUser> listClassId = cud.getAllClassUser();
            List<User> listUserId = udao.UserList();
            List<Team> listTeamId = dao.getAllTeam();
            request.setAttribute("cu", cu);
            request.setAttribute("listC", listClassId);
            request.setAttribute("listUserId", listUserId);
            request.setAttribute("listT", listTeamId);
            request.getRequestDispatcher("View/ClassUserAdd.jsp").forward(request, response);

        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("utf-8");
        PrintWriter out = response.getWriter();
        String class_id = request.getParameter("class_id");
        String team_id = request.getParameter("team_id");
        String user_id = request.getParameter("user_id");
        String dropout_date = request.getParameter("dropout_date");
        String status = request.getParameter("status");
        String user_notes = request.getParameter("user_notes");
        ClassUserDAO cud = new ClassUserDAO();
        try {
            cud.AddClassUser(class_id, team_id, user_id, dropout_date, user_notes, status);

            out.println("<script type=\"text/javascript\">");
            out.println("alert('Update Successful');");
            out.println("location='classuserlist'");
            out.println("</script>");
        } catch (Exception e) {
            System.out.println("ERROR HERE" + e);
        }
        request.getRequestDispatcher("classuserlist").include(request, response);

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
