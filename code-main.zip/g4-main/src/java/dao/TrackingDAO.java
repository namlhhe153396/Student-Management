/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.common.DBContext;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Function;
import model.Milestone;
import model.Team;
import model.Tracking;

/**
 *
 * @author NamOK
 */
public class TrackingDAO extends DBContext {

//    public List<Tracking> getAllTracking() {
//        String sql = "select * from tracking ;";
//        List<Tracking> list = new ArrayList();
//        try {
//            PreparedStatement st = getConnection().prepareStatement(sql);
//            ResultSet rs = st.executeQuery();
//            //get all trackings 
//            while (rs.next()) {
//                list.add(new Tracking(rs.getInt("tracking_id"), rs.getInt("team_id"), rs.getInt("milestone_id"), rs.getInt("function_id"),
//                        rs.getInt("assigner_id"), rs.getInt("assignee_id"), rs.getString("tracking_note"), rs.getString("updates"), rs.getInt("status")));
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//        return list;
//    }
    public List<Tracking> getAllTrackings() {
        String sql = "select * from tracking \n"
                + "join team , milestone ,function_tb \n"
                + "where tracking.team_id = team.team_id and milestone.milestone_id = tracking.milestone_id and tracking.function_id = function_tb.function_id";
        List<Tracking> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all trackings 
            while (rs.next()) {
                list.add(new Tracking(rs.getInt("tracking_id"), rs.getString("tracking_name"), rs.getInt("team_id"), rs.getString("team_name"), rs.getInt("milestone_id"), rs.getString("milestone_name"), rs.getInt("function_id"), rs.getString("function_name"),
                        rs.getInt("assigner_id"), rs.getInt("assignee_id"), rs.getString("tracking_note"), rs.getString("updates"), rs.getInt("status")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Tracking> getAllTrackingSort(String str) {
        String sql = "select * from tracking \n"
                + "join team , milestone ,function_tb \n"
                + "where tracking.team_id = team.team_id and milestone.milestone_id = tracking.milestone_id and tracking.function_id = function_tb.function_id\n"
                + "order by  " + str;
        List<Tracking> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all trackings 
            while (rs.next()) {
                list.add(new Tracking(rs.getInt("tracking_id"), rs.getString("tracking_name"), rs.getInt("team_id"), rs.getString("team_name"), rs.getInt("milestone_id"), rs.getString("milestone_name"), rs.getInt("function_id"), rs.getString("function_name"),
                        rs.getInt("assigner_id"), rs.getInt("assignee_id"), rs.getString("tracking_note"), rs.getString("updates"), rs.getInt("status")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Tracking> getTrackingbyString(String str) {
        String sql = "select * from tracking \n"
                + "join team , milestone ,function_tb \n"
                + "where tracking.team_id = team.team_id and milestone.milestone_id = tracking.milestone_id and tracking.function_id = function_tb.function_id ";
        sql += str;
        List<Tracking> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all trackings 
            while (rs.next()) {
                list.add(new Tracking(rs.getInt("tracking_id"), rs.getString("tracking_name"), rs.getInt("team_id"), rs.getString("team_name"), rs.getInt("milestone_id"), rs.getString("milestone_name"), rs.getInt("function_id"), rs.getString("function_name"),
                        rs.getInt("assigner_id"), rs.getInt("assignee_id"), rs.getString("tracking_note"), rs.getString("updates"), rs.getInt("status")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Tracking GetTrackingbyID(int id) throws Exception {
        String sql = "select * from tracking \n"
                + "join team , milestone ,function_tb \n"
                + "where tracking.team_id = team.team_id and milestone.milestone_id = tracking.milestone_id and tracking.function_id = function_tb.function_id and tracking.tracking_id =  ? ;" ;
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setInt(1, id);

            ResultSet rs = st.executeQuery();
            if (rs.next()) {

                return new Tracking(rs.getInt("tracking_id"), rs.getString("tracking_name"), rs.getInt("team_id"), rs.getString("team_name"), rs.getInt("milestone_id"), rs.getString("milestone_name"), rs.getInt("function_id"), rs.getString("function_name"),
                        rs.getInt("assigner_id"), rs.getInt("assignee_id"), rs.getString("tracking_note"), rs.getString("updates"), rs.getInt("status"));
            }
        } catch (SQLException e) {
        }
        return null;
    }

    public List<Team> getAllTeam() {
        String sql = "select * from team ;";
        List<Team> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all trackings 
            while (rs.next()) {
                list.add(new Team(rs.getInt("team_id"), rs.getString("team_name")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Milestone> getAllMilestone() {
        String sql = "select * from  milestone ;";
        List<Milestone> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all trackings 
            while (rs.next()) {
                list.add(new Milestone(rs.getInt("milestone_id"), rs.getString("milestone_name")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Function> getAllFunction() {
        String sql = "select * from function_tb ;";
        List<Function> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all trackings 
            while (rs.next()) {
                list.add(new Function(rs.getInt("function_id"), rs.getString("function_name")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void updateTracking(Tracking mi) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
