/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author ASUS
 */
public class MD5Dao {

    public String convertHashToString(String text) throws NoSuchAlgorithmException {
//        MessageDigest md = MessageDigest.getInstance("MD5");
//        byte[] hashInBytes = md.digest(text.getBytes(StandardCharsets.UTF_8));
//        StringBuilder sb = new StringBuilder();
//        for (byte b : hashInBytes) {
//            sb.append(String.format("%02x", b));
//        }
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(text.getBytes());
        byte[] digest = md.digest();
        String myHash = DatatypeConverter
                .printHexBinary(digest).toUpperCase();
//        return sb.toString();
        return myHash;
    }

    public String CheckPasswordMD5(String pass) {
        MD5Dao md5 = new MD5Dao();
        UserDao userDao = new UserDao();
        String passInData = null;
        try {
            passInData = md5.convertHashToString(pass);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(MD5Dao.class.getName()).log(Level.SEVERE, null, ex);
        }

        return passInData;
    }

    public static boolean verify(String inputPassword, String hashPassWord)
            throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(inputPassword.getBytes());
        byte[] digest = md.digest();
        String myChecksum = DatatypeConverter
                .printHexBinary(digest).toUpperCase();
        return hashPassWord.equals(myChecksum);
    }

    public static void main(String[] args) throws NoSuchAlgorithmException {
        MD5Dao md5 = new MD5Dao();
//        System.out.println(md5.convertHashToString("123456"));
//        String pass = md5.CheckPasswordMD5("nam123");
        String pass = md5.CheckPasswordMD5("phuc123");
        System.out.println(pass);
    }
}
