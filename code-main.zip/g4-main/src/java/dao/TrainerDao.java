/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.common.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Team_evaluation;

/**
 *
 * @author My PC
 */
public class TrainerDao extends DBContext {

    Connection conn = null;        //ket noi voi sql sever
    PreparedStatement ps = null;   //nem cau lenh query sang sql sever
    ResultSet rs = null;           //nhan ket qua tra ve

    public List<Team_evaluation> getAllTeam_evaluation(int index) {
        String sql = "select te.team_eval_id, ecr.criteria_name, t.class_code, ec.subject_name, t.team_name, ec.iteration_name,  te.grade, te.note from team_evaluation te inner join evaluation_criteria ec inner join team t inner join evaluation_criteria ecr on te.criteria_id = ec.criteria_id and te.team_id = t.team_id and te.criteria_id = ecr.criteria_id where t.class_code = 'SE1603' and ec.iteration_name = 'Iter1' limit ?, 7";
        List<Team_evaluation> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 7);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team_evaluation(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

        public List<Team_evaluation> getAllTeam_evaluationSt(String team) {
        String sql = "select te.team_eval_id, ecr.criteria_name, t.class_code, ec.subject_name, t.team_name, ec.iteration_name,  te.grade, te.note from team_evaluation te inner join evaluation_criteria ec inner join team t inner join evaluation_criteria ecr on te.criteria_id = ec.criteria_id and te.team_id = t.team_id and te.criteria_id = ecr.criteria_id where te. team_id = (select team_id from class_user where user_id =?)";
        List<Team_evaluation> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team_evaluation(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public int getTotalTeam_evaluation() {
        String query = "select count(*) from team_evaluation";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public Team_evaluation getTeam_evaluationByID(String id) {
        String query = "select te.team_eval_id, te.evaluation_id, t.class_code, ec.subject_name, t.team_name, ecr.criteria_name, ec.iteration_name,  te.grade, te.note from team_evaluation te inner join evaluation_criteria ec inner join team t inner join evaluation_criteria ecr on te.criteria_id = ec.criteria_id and te.team_id = t.team_id and te.criteria_id = ecr.criteria_id where team_eval_id = ?; ";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Team_evaluation(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public void AddTeam_evaluation(String evaluation_id, String criteria_id, String team_id, String grade, String note) throws Exception {
        String sql = "insert into team_evaluation(evaluation_id,criteria_id,team_id,grade,note) values (?, ?, ?, ?, ?);";
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, evaluation_id);
            st.setString(2, criteria_id);
            st.setString(3, team_id);
            st.setString(4, grade);
            st.setString(5, note);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public void EditTeam_evaluation(String evaluation_id, String criteria_id, String team_id, String grade, String note, String id) throws Exception {
        String sql = "update team_evaluation set evaluation_id = ?, criteria_id = ?, team_id = ?, grade = ?, note = ? where team_eval_id = ?;";
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, evaluation_id);
            st.setString(2, criteria_id);
            st.setString(3, team_id);
            st.setString(4, grade);
            st.setString(5, note);
            st.setString(6, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public List<Team_evaluation> getTeam_evaluationSort(String str) {
        String sql = "select te.team_eval_id, ecr.criteria_name, t.class_code, ec.subject_name, t.team_name, ec.iteration_name,  te.grade, te.note from team_evaluation te inner join evaluation_criteria ec inner join team t inner join evaluation_criteria ecr on te.criteria_id = ec.criteria_id and te.team_id = t.team_id and te.criteria_id = ecr.criteria_id"
                + " order by  ";
        sql += str;
        List<Team_evaluation> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //Get user from database 
            while (rs.next()) {
                list.add(new Team_evaluation(rs.getString("team_eval_id"), rs.getString("criteria_name"), rs.getString("class_code"),
                        rs.getString("subject_name"), rs.getString("team_name"), rs.getString("iteration_name"), rs.getString("grade"), rs.getString("note")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<model.Class> getAllListClass() {
        String sql = "select * from spm_database.class";
        List<model.Class> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new model.Class(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team_evaluation> search(String txtSearch) {
        List<Team_evaluation> list = new ArrayList<>();
        String query = "select te.team_eval_id, ecr.criteria_name, t.class_code, ec.subject_name, t.team_name, ec.iteration_name,  te.grade, te.note from team_evaluation te inner join evaluation_criteria ec inner join team t inner join evaluation_criteria ecr on te.criteria_id = ec.criteria_id and te.team_id = t.team_id and te.criteria_id = ecr.criteria_id where te.team_eval_id like ? or ec.subject_name like ? or t.team_name like ? or te.grade like ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team_evaluation(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team_evaluation> searchFil(String txtSearch) {
        List<Team_evaluation> list = new ArrayList<>();
        String query = "select te.team_eval_id, ecr.criteria_name, t.class_code, ec.subject_name, t.team_name, ec.iteration_name,  te.grade, te.note from team_evaluation te inner join evaluation_criteria ec inner join team t inner join evaluation_criteria ecr on te.criteria_id = ec.criteria_id and te.team_id = t.team_id and te.criteria_id = ecr.criteria_id where ecr.criteria_name like ? or t.class_code like ? or ec.iteration_name like ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");;
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team_evaluation(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
    
    public static void main(String[] args) {
        try {
            TrainerDao dao = new TrainerDao();
            System.out.println(dao.search("Dog"));
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
