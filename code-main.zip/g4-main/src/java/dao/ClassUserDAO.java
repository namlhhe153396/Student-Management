/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import controller.common.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ClassUser;
import model.Subject;

/**
 *
 * @author 84337
 */
public class ClassUserDAO extends DBContext {

    Connection conn = null;        //ket noi voi sql sever
    PreparedStatement ps = null;   //nem cau lenh query sang sql sever
    ResultSet rs = null;

    public List<ClassUser> getAllClassUser() {
        String sql = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, cl.dropout_date, cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id order by cl.class_user_id;";
        List<ClassUser> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<ClassUser> getAllClassUserSort(String str) {
        String sql = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, cl.dropout_date, cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id order by "+str;
        List<ClassUser> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public void EditClassUser(String Class_id, String team_id, String user_id, String dropout_date, String user_notes, String ongoing_eval, String final_pres_eval, String final_topic_eval, String status, String id) {
        String sql = "update spm_database.class_user set class_id = ? , team_id = ? ,  user_id = ? , dropout_date  = STR_TO_DATE(?, '%d-%m-%Y'),user_notes = ?,ongoing_eval=? , final_pres_eval=? , final_topic_eval=?, status =? where class_user_id = ?;";

        try {
            PreparedStatement ps = getConnection().prepareStatement(sql);
            ps.setString(1, Class_id);

            ps.setString(2, team_id);
            ps.setString(3, user_id);
//            ps.setString(4, avatar);
            ps.setString(4, dropout_date);
            ps.setString(5, user_notes);
            ps.setString(6, ongoing_eval);
            ps.setString(7, final_pres_eval);
            ps.setString(8, final_topic_eval);
            ps.setString(9, status);
            ps.setString(10, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    public List<ClassUser> getAllClassUserByClass(String cid) {
        String sql = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, cl.dropout_date, cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id where c.class_id = ?;";
        List<ClassUser> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1,cid);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<model.Class> getAllClass() {
        String sql = "select * from class";
        List<model.Class> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new model.Class(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<ClassUser> searchClassUser(String txtSearch) {
        List<ClassUser> list = new ArrayList<>();
        String query = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, cl.dropout_date, cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id \n"
                + " and u.full_name like ? or u.roll_number like ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void changeStatusClassUser(String id) throws Exception {

        String sql = "update class_user set status =  ?  where class_user_id = ?;";
        String status = "1";
        ClassUser sb = new ClassUser();
        sb = getClassUserByID(id);
        if (sb.getStatus().compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, status);
            st.setString(2, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public ClassUser getClassUserByID(String id) {
        String query = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, DATE_FORMAT(cl.dropout_date, '%d-%m-%Y'), cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id and  cl.class_user_id = ?; ";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new ClassUser(rs.getString(1),
                       rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public List<ClassUser> ClassUserStatus1() {
        String sql = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, cl.dropout_date, cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id and cl.status = 1  ";
        List<ClassUser> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                       rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<ClassUser> ClassUserStatus0() {
        String sql = "select cl.class_user_id,  cl.class_id, c.class_code,cl.user_id, u.full_name, u.roll_number,\n"
                + " cl.team_id, t.team_name, cl.dropout_date, cl.user_notes,\n"
                + "cl.ongoing_eval, cl.final_pres_eval , cl.final_topic_eval, \n"
                + "cl.status\n"
                + " from class_user cl join class c join team t join user u\n"
                + "on c.class_id = cl.class_id and cl.team_id = t.team_id \n"
                + "and cl.user_id = u.user_id and cl.status = 0 ";
        List<ClassUser> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                       rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public void AddClassUser(String class_id, String team_id, String user_id,String dropout_date, String user_note, String status)  {
        String sql = "insert into class_user ( class_id, team_id, user_id, dropout_date, user_notes, status) \n" +
"values (?, ?, ?, STR_TO_DATE(?, '%d-%m-%Y'), ?,  ?);";

        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, class_id);
            st.setString(2, team_id);
            st.setString(3, user_id);
            st.setString(4, dropout_date);
            st.setString(5, user_note);
            st.setString(6, status);
            ///...................
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        } catch (Exception ex) {
            Logger.getLogger(ClassUserDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public static void main(String[] args) {
        ClassUserDAO dao = new  ClassUserDAO();
        dao.AddClassUser("1", "1", "HE150004", "17-08-2022", "HA", "1");
    }
}
