/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.common.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Criteria;
import model.Iteration;
import model.Setting;
import model.Subject;
import model.SubjectSetting;
import model.Team;
import model.Class;
import model.ClassUser;
import model.Issues;
import model.Tracking;
import model.User;
import org.json.JSONArray;
import org.json.JSONObject;
import model.Class;
import model.Function;
import model.Milestone;

/**
 *
 * @author PC PHUC
 */
public class AdminDao extends DBContext {

    Connection conn = null;        //ket noi voi sql sever
    PreparedStatement ps = null;   //nem cau lenh query sang sql sever
    ResultSet rs = null;           //nhan ket qua tra ve

    // Setting //
    public List<Setting> getAllSetting(int index) {
        String sql = "select * from setting ORDER BY setting_id limit ?, 5 ;";
        List<Setting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Setting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Setting> getAllSetting() {
        String sql = "select * from setting ;";
        List<Setting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Setting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> getAllSubjectSetting() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1  \n"
                + "order by ss.subject_setting_id ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public SubjectSetting getAllSubjectSettingAllbyID(String id) {
        String sql = "select ss.subject_setting_id ,ss.setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "                from subject_setting ss \n"
                + "                join subject sb join setting st\n"
                + "                on ss.subject_id =sb.subject_id\n"
                + "                and ss.setting_id = st.setting_id\n"
                + "                where ss.subject_setting_id = ?  \n"
                + "                order by ss.subject_setting_id";
//        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public int getTotalSetting() {
        String query = "select count(*) from setting;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public int getTotalSearchSetting(String txtSearch) {
        String query = "select count(*) from setting where type_id like ? or setting_title like ?"
                + " or subject_name like ? or setting_value like ? or display_order like ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public List<Setting> search(String txtSearch, int index) {
        List<Setting> list = new ArrayList<>();
        String query = "select * from setting where type_id like ? or setting_title like ?"
                + "or subject_name like ? or setting_value like ? or display_order like ?"
                + "ORDER BY setting_id limit ?,5 ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setInt(6, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Setting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

//    public void deleteSubject(String id) {
//        String query = "delete from subject_setting where type_id = ?;";
//        try {
//            conn = new DBContext().getConnection();//mo ket noi voi sql
//            ps = conn.prepareStatement(query);
//            ps.setString(1, id);
//            ps.executeUpdate();
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//    }
    public Setting getSettingByID(String id) {
        String query = "select * from setting where type_id = ?;";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Setting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public void updatetSetting(String subject_name, String setting_title, String setting_value,
            String display_order, String status, String description, String type_id) {
        String query = "update setting set \n"
                + "setting_title = ?, subject_name = ?, setting_value = ?, "
                + "display_order = ?, status = ? , description = ?\n"
                + "where type_id = ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, setting_title);
            ps.setString(2, subject_name);
            ps.setString(3, setting_value);
            ps.setString(4, display_order);
            ps.setString(5, status);
            ps.setString(6, description);
            ps.setString(7, type_id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

//    public Setting checkSubjectExist(String type_id, String subject_name, String subject_value) {
//        String query = "select type_id, subject_name, subject_value\n"
//                + "from subject_setting ss join subject s on ss.subject_id = s.subject_id\n"
//                + "where type_id = ? or subject_name = ? or subject_value = ? ORDER BY setting_id asc;";
//        try {
//            conn = new DBContext().getConnection();//mo ket noi voi sql
//            ps = conn.prepareStatement(query);
//            ps.setString(1, type_id);
//            ps.setString(2, subject_name);
//            ps.setString(3, subject_value);
//            rs = ps.executeQuery();
//            while (rs.next()) {
//                return new Setting(rs.getString(1),
//                        rs.getString(2),
//                        rs.getString(3),
//                        rs.getString(4),
//                        rs.getString(5),
//                        rs.getString(6),
//                        rs.getString(7));
//            }
//        } catch (Exception e) {
//            System.out.println(e);
//        }
//
//        return null;
//    }
    public void addSubject(int type_id, String setting_title, String subject_name, String setting_value,
            String display_order, int status, String description) {
        String query = "insert into setting ( type_id, setting_title, subject_name, setting_value, display_order, status, description) \n"
                + "values (?, ?, ?, ?, ?, ?, ? );";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setInt(1, type_id);
            ps.setString(2, setting_title);
            ps.setString(3, subject_name);
            ps.setString(4, setting_value);
            ps.setString(5, display_order);
            ps.setInt(6, status);
            ps.setString(7, description);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void addIssue(String assignee_id, String issue_title, String description, int gitlab_id, String gitlab_url, String created_date, String due_date, 
            int team_id, int milestone_id, int function_ids, String labels, int status) {
        String query = "insert into issue( assignee_id, issue_title, description, gitlab_id, gitlab_url, created_date, due_date, team_id, milestone_id, function_ids, labels, status)  \n"
                + "values(?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?, ? );";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1,assignee_id );
            ps.setString(2, issue_title);
            ps.setString(3, description);
            ps.setInt(4, gitlab_id);
            ps.setString(5, gitlab_url);
            ps.setString(6, created_date);
            ps.setString(7, due_date);
            ps.setInt(8, team_id);
            ps.setInt(9, milestone_id);
            ps.setInt(10, function_ids);
            ps.setString(11, labels);
            ps.setInt(12, status);
//            ps.setString(11, description);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void changeStatus(String id) {
        String sql = " update setting set status = ? where type_id = ?; ";
        String status = "1";
        Setting sb = new Setting();
        sb = getSettingByID(id);
        if (sb.getStatus().compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setString(2, id);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Setting> getSettingbyString(String str) throws Exception {
        String sql = "select * from setting where  1=1 ";
        List<Setting> list = new ArrayList();

        if (!str.isEmpty()) {
            sql = sql + str;
        }
        System.out.println(sql);
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Setting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    // Setting //
    // Iteration //
    public Iteration getIterationByID(int id) {
        String query = "select * from iteration where iteration_id = ?;";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Iteration(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDate(4),
                        rs.getInt(5));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public void addIteration(String subject_id, String iteration_name, String duration, String status) {
        String query = "insert into iteration (subject_id, iteration_name, duration, status)\n"
                + "values(?, ?, ?, ?);";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, subject_id);
            ps.setString(2, iteration_name);
            ps.setString(3, duration);
            ps.setString(4, status);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void updatetIteration(String subject_id, String iteration_name,
            String duration, String status, int id) {
        String query = "update iteration set subject_id = ? , iteration_name = ?"
                + ",  duration = ?, status = ? where iteration_id = ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, subject_id);
            ps.setString(2, iteration_name);
            ps.setString(3, duration);
            ps.setString(4, status);
            ps.setInt(5, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Iteration> getAllIter() {
        String sql = "select * from iteration  ";
        List<Iteration> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Iteration(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDate(4),
                        rs.getInt(5)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        //System.out.println(list);
        return list;
    }

    public List<Subject> getAllIterSubId() {
        String sql = "select subject_id from subject;";
        List<Subject> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString("subject_id")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        //System.out.println(list);
        return list;
    }

    public List<Iteration> getAllIterationSort(String str) {
        String sql = "select * from iteration \n"
                + "order by  " + str;
        List<Iteration> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            //get all Iteration 
            while (rs.next()) {
                list.add(new Iteration(rs.getInt("iteration_id"), rs.getString("subject_id"), rs.getString("iteration_name"), rs.getDate("duration"), rs.getInt("status")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void changeStatusIter(int id) throws Exception {

        String sql = " update iteration set  status =  ?   where iteration_id = ? ";
        int status = 1;
        Iteration i = new Iteration();
        i = getIterationByID(id);
        if (i.getStatus() == 0) {
            status = 1;
        } else {
            status = 0;
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            //............
            st.setInt(1, status);
            st.setInt(2, id);
            ///...................
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public Iteration checkIterExist(String name) {
        String query = "select * from iteration where iteration_name = ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, name);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Iteration(rs.getString("subject_id"),
                        rs.getString("iteration_name"),
                        rs.getDate("duration"),
                        rs.getInt("status"));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        return null;
    }

    public List<Iteration> getIterbyString(String str) throws Exception {
        String sql = "select * from Iteration where  1=1 "; //and iteration_name = \"iter1\"";
        List<Iteration> list = new ArrayList();

        if (!str.isEmpty()) {
            sql = sql + str;
        }
        System.out.println(sql);
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Iteration(rs.getInt("iteration_id"), rs.getString("subject_id"), rs.getString("iteration_name"), rs.getDate("duration"), rs.getInt("status")));
            }
        } catch (SQLException e) {

        }
        return list;
    }

    // Iteration //
    // Subject Setting //
    public List<SubjectSetting> getAllSubjectSetting(int index) {
        String sql = "select * from subject_setting ORDER BY setting_id limit ?, 5 ;";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public SubjectSetting getSubjectSettingByID(String id) {
        String query = "select * from subject_setting where setting_id = ?;";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public void changeStatusSS(String id) {

        String sql = " update subject_setting set  status =  ?   where type_id = ? ";
        String status = "1";
        SubjectSetting sb = new SubjectSetting();
        sb = getSubjectSettingByID(id);
        if (sb.getStatus().compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(sql);
            ps.setString(1, status);
            ps.setString(2, id);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Subject> getAllSubject() {
        String sql = "select * from subject ";
        List<Subject> list = new ArrayList();
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString("subject_id"), rs.getString("subject_code"), rs.getString("subject_name"), rs.getString("author_id"), rs.getString("status")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        //System.out.println(list);
        return list;
    }

    public void updatetSubjectSetting(String subject_id, String setting_id, String type_id, String title,
            String value, String display_order, String status, String subSid) {
        String query = "update spm_database.subject_setting set \n"
                + "subject_id = ?, setting_id = ?, type_id = ?, setting_title = ?, "
                + "setting_value = ?, display_order = ? , status = ?\n"
                + "where subject_setting_id = ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, subject_id);
            ps.setString(2, setting_id);
            ps.setString(3, type_id);
            ps.setString(4, title);
            ps.setString(5, value);
            ps.setString(6, display_order);
            ps.setString(7, status);
            ps.setString(8, subSid);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // Subject Setting //
    // Criteria //
    public List<Criteria> getAllCriteria(int index) {
        String sql = "select * from evaluation_criteria ORDER BY criteria_id limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getAllSubjectName() {
        String sql = "select subject_id, subject_name from subject;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString("subject_id"), rs.getString("subject_name")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void changeStatusCriteria(int id) throws Exception {

        String sql = " update evaluation_criteria set  status =  ?   where criteria_id = ? ";
        int status = 1;
        Criteria c = new Criteria();
        c = getCriteriaByID(id);
        if (c.getStatus() == 0) {
            status = 1;
        } else {
            status = 0;
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            //............
            st.setInt(1, status);
            st.setInt(2, id);
            ///...................
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public Criteria getCriteriaByID(int id) {
        String query = "select * from evaluation_criteria where criteria_id = ?;";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public int getTotalCriteria() {
        String query = "select count(*) from evaluation_criteria;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public List<Criteria> getCritbyString(String str) throws Exception {
        String sql = "select * from evaluation_criteria where  1=1 ";
        List<Criteria> list = new ArrayList();

        if (!str.isEmpty()) {
            sql = sql + str;
        }
        System.out.println(sql);
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public List<Criteria> searchCriteria(String txtSearch, int index) {
        List<Criteria> list = new ArrayList<>();
        String query = "select * from evaluation_criteria where criteria_id like ? or iteration_id like ?"
                + "or iteration_name like ? or evaluation_weight like ? or team_evaluation like ? "
                + "or criteria_order like ? or max_loc like ? or criteria_name like ? or subject_name like ?"
                + "ORDER BY criteria_id limit ?,5 ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
            ps.setString(7, "%" + txtSearch + "%");
            ps.setString(8, "%" + txtSearch + "%");
            ps.setString(9, "%" + txtSearch + "%");
            ps.setInt(10, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public int getTotalSearchCriteria(String txtSearch) {
        String query = "select count(*) from evaluation_criteria where criteria_id like ? or iteration_id like ?"
                + "or iteration_name like ? or evaluation_weight like ? or team_evaluation like ? "
                + "or criteria_order like ? or max_loc like ?";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
            ps.setString(7, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public void updatetCriteria(String criteria_name, String subject_name, String iteration_name, String evaluation_weight,
            String team_evaluation, String criteria_order, String max_loc, String status, String description, int id) {
        String query = "update evaluation_criteria set criteria_name = ?, subject_name = ?, iteration_name = ? , evaluation_weight = ?"
                + ",  team_evaluation = ?, criteria_order = ?, max_loc = ?, status = ?, description = ? where criteria_id = ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, criteria_name);
            ps.setString(2, subject_name);
            ps.setString(3, iteration_name);
            ps.setString(4, evaluation_weight);
            ps.setString(5, team_evaluation);
            ps.setString(6, criteria_order);
            ps.setString(7, max_loc);
            ps.setString(8, status);
            ps.setString(9, description);
            ps.setInt(10, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void addCriteria(String criteria_name, String subject_name, String iteration_name, String evaluation_weight,
            String team_evaluation, String criteria_order, String max_loc, String status, String description) {
        String query = "insert into evaluation_criteria (criteria_name, iteration_name, subject_name, evaluation_weight, team_evaluation, criteria_order, max_loc, status, description)\n"
                + "values(?, ?, ?, ?, ?, ?, ?, ?, ?);";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, criteria_name);
            ps.setString(2, iteration_name);
            ps.setString(3, subject_name);
            ps.setString(4, evaluation_weight);
            ps.setString(5, team_evaluation);
            ps.setString(6, criteria_order);
            ps.setString(7, max_loc);
            ps.setString(8, status);
            ps.setString(9, description);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Criteria> sortCriteriaIDdesc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY criteria_id desc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortCriteriaIDasc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY criteria_id asc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortIterNameasc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY iteration_name asc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortIterNamedesc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY iteration_name desc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortWeightasc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY evaluation_weight asc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortWeightdesc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY evaluation_weight desc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortTeamasc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY team_evaluation asc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortTeamdesc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY team_evaluation desc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortStatusasc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY status asc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortStatusdesc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY status desc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortLocasc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY max_loc asc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Criteria> sortLocdesc(int index) {
        String sql = "select * from evaluation_criteria ORDER BY max_loc desc limit ?, 5;";
        List<Criteria> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Criteria(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getInt(6),
                        rs.getInt(7),
                        rs.getInt(8),
                        rs.getInt(9),
                        rs.getInt(10),
                        rs.getString(11)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    // Criteria //
    // Team //
    public List<Team> getAllTeam(int index) {
        String sql = "select * from team ORDER BY team_id limit ?, 5;";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Team getTeamByID(int id) {
        String query = "select * from team where team_id = ?;";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public int getTotalTeam() {
        String query = "select count(*) from team;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public void changeStatusTeam(int id) throws Exception {

        String sql = " update team set  status =  ? where team_id = ? ";
        int status = 1;
        Team t = new Team();
        t = getTeamByID(id);
        if (t.getStatus() == 0) {
            status = 1;
        } else {
            status = 0;
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            //............
            st.setInt(1, status);
            st.setInt(2, id);
            ///...................
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public List<Team> getTeambyString(String str) throws Exception {
        String sql = "select * from team where  1=1 ";
        List<Team> list = new ArrayList();

        if (!str.isEmpty()) {
            sql = sql + str;
        }
        System.out.println(sql);
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);

            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {

        }
        return list;
    }

    public List<Team> getAllTopic() {
        String sql = "select distinct topic_name from team;";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getString("topic_name")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> searchTeam(String txtSearch, int index) {
        List<Team> list = new ArrayList<>();
        String query = "select * from team where team_id like ? or class_id like ? or team_name like ?"
                + "or class_code like ? or topic_code like ? or topic_name like ?"
                + "ORDER BY team_id limit ?,5 ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
            ps.setInt(7, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public int getTotalSearchTeam(String txtSearch) {
        String query = "select count(*) from team where team_id like ? or class_id like ?"
                + "or class_code like ? or topic_code like ? or topic_name like ?";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public List<Class> getAllClassCode() {
        String sql = "select class_code from class;";
        List<Class> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Class(rs.getString("class_code")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void updatetTeam(String class_code, String topic_code, String team_name,
            String topic_name, String gitlab_url, String status, int id) {
        String query = "update team set class_code = ? , topic_code = ? , team_name = ?"
                + ",  topic_name = ?, gitlab_url = ?, status = ? where team_id = ?;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, class_code);
            ps.setString(2, topic_code);
            ps.setString(3, team_name);
            ps.setString(4, topic_name);
            ps.setString(5, gitlab_url);
            ps.setString(6, status);
            ps.setInt(7, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void addTeam(String class_code, String topic_code, String team_name,
            String topic_name, String gitlab_url, String status) {
        String query = "insert into team (team_name, class_code, topic_code, topic_name, gitlab_url, status)\n"
                + "values(?, ?, ?, ?, ?, ?);";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, team_name);
            ps.setString(2, class_code);
            ps.setString(3, topic_code);
            ps.setString(4, topic_name);
            ps.setString(5, gitlab_url);
            ps.setString(6, status);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Team> sortTeamIDasc(int index) {
        String sql = "select * from team ORDER BY team_id asc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortTeamIDdesc(int index) {
        String sql = "select * from team ORDER BY team_id desc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortClassasc(int index) {
        String sql = "select * from team ORDER BY class_code asc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortClassdesc(int index) {
        String sql = "select * from team ORDER BY class_code desc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortTopicCodeasc(int index) {
        String sql = "select * from team ORDER BY topic_code asc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortTopicCodedesc(int index) {
        String sql = "select * from team ORDER BY topic_code desc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortTopicNameasc(int index) {
        String sql = "select * from team ORDER BY topic_name asc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyNameDESC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by sb.subject_name DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyNameDESCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by sb.subject_name DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyNameASC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by sb.subject_name ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyNameASCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by sb.subject_name ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTypeASC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by ss.type_id ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTypeASCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by ss.type_id ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyValueASC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by ss.setting_value ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyValueASCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by ss.setting_value ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyValueDESC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by ss.setting_value DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyValueDESCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by ss.setting_value DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTitleASC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by ss.setting_title ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTitleASCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by ss.setting_title ASC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTitleDESC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by  ss.setting_title DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTitleDESCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by  ss.setting_title DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTypeDESC() {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1\n"
                + "order by ss.type_id DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SortSubjectbyTypeDESCForA(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "order by ss.type_id DESC ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> getAllSubjectSettingForAuthor(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ? \n"
                + "order by ss.subject_setting_id ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(
                        rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortTopicNamedesc(int index) {
        String sql = "select * from team ORDER BY topic_name desc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortStatusTeamasc(int index) {
        String sql = "select * from team ORDER BY status asc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Team> sortStatusTeamdesc(int index) {
        String sql = "select * from team ORDER BY status desc limit ?, 5; ";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getInt(8)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    // Team //

    // Class User //
    public List<ClassUser> getAllClassUser() {
        String sql = "select * from class_user";
        List<ClassUser> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public int getTotalIssues() {
        String query = "select count(*) from spm_database.issue;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public List<Issues> getAllIssue() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i join user u join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 1";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

<<<<<<< HEAD
    public List<Issues> SortIssueDescByTeam() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by team_id desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> SortIssueDescByAssignee() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by u.full_name desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> SortIssueAsscByAssignee() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by u.full_name asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> SortIssueAscByTeam() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by team_id asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortIssueTitleDesc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by issue_title desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortIssueTitleAsc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by issue_title asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortDueDateAsc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.due_date asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortLableDesc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.labels desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Issues> sortLableAsc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.labels";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortDueDateDesc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.due_date desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

=======
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5
    public List<Issues> getAllIssueTeam() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,i.created_date,i.due_date,t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i join user u join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public int syncIssuesGit(String project_id, String token) {
        int n = 0;
        //
        Vector<String> issues_iids = new Vector();
        Vector<String> issues_titles = new Vector();
        Vector<String> issues_descriptions = new Vector();
        Vector<String> issues_gitlab_id = new Vector();
        Vector<String> issues_gitlab_url = new Vector();
        Vector<String> issues_created_date = new Vector();
        Vector<String> issues_due_date = new Vector();
        Vector<String> issues_team_id = new Vector();
        Vector<String> issues_milestone_id = new Vector();
        Vector<String> issues_function_ids = new Vector();
        Vector<String> issues_labels = new Vector();
        Vector<String> issues_status = new Vector();
        String keys = "page";
//        Vector<String> values = new Vector<>();
        for (int j = 10; j > 0; --j) {
            int warring = 0;
            System.out.println("so dem " + j);
            String values = String.valueOf(j);
            //get Git to json
            JSONArray jsons = new JSONArray();
            jsons = API.getJsonArrayGet("projects", project_id, "issues", keys, values, token);
            if (jsons != null) {
                for (int i = 0; i < jsons.length(); i++) {
                    JSONObject json = jsons.getJSONObject(i);

                    issues_iids.add(json.get("iid").toString().trim());
                    issues_titles.add(json.get("title").toString().trim());
                    issues_descriptions.add(json.get("description").toString().trim());
                    issues_gitlab_id.add(json.get("project_id").toString().trim());
                    issues_gitlab_url.add(json.get("web_url").toString().trim());
                    issues_created_date.add(json.get("created_at").toString().trim().substring(0, 10));
                    issues_due_date.add(json.get("updated_at").toString().trim().substring(0, 10));
//                issues_team_id.add(json.get("authorid").toString().trim());
//                issues_milestone_id.add(json.get("milestone_id").toString().trim());
//                issues_function_ids.add(json.get("function_ids").toString().trim());
                    issues_labels.add(json.get("labels").toString().trim());
//                issues_status.add(json.get("status").toString().trim());
                }

            }

        }
        // check
//        for (int i = 0; i < issues_iids.size(); i++) {
//            System.out.println(issues_iids.get(i));
//            System.out.println(issues_titles.get(i));
//            System.out.println(issues_descriptions.get(i));
//            System.out.println(issues_gitlab_id.get(i));
//            System.out.println(issues_gitlab_url.get(i));
//            System.out.println(issues_created_date.get(i));
//        }

        //updateDateBase
        try {
            for (int i = 0; i < issues_iids.size(); i++) {
                String SqlPost = "INSERT INTO `spm_database`.`issue`\n"
                        + "(`issue_id`,\n"
                        + "`issue_title`,\n"
                        + "`description`,\n"
                        + "`gitlab_id`,\n"
                        + "`gitlab_url`,\n"
                        + "`created_date`,\n"
                        + "`due_date`,\n"
                        + "`labels`)\n"
                        + "VALUES\n"
                        + "(?,\n"
                        + "?,\n"
                        + "?,\n"
                        + "?,\n"
                        + "?,\n"
                        + "?,\n"
                        + "?,\n"
                        + "?);";

                try {
                    conn = new DBContext().getConnection();//mo ket noi voi sql
                } catch (Exception ex) {
                    Logger.getLogger(AdminDao.class.getName()).log(Level.SEVERE, null, ex);
                }
                ps = conn.prepareStatement(SqlPost);
                ps.setString(1, issues_iids.get(i));
                ps.setString(2, issues_titles.get(i));
                ps.setString(3, issues_descriptions.get(i));
                ps.setString(4, issues_gitlab_id.get(i));
                ps.setString(5, issues_gitlab_url.get(i));
                ps.setString(6, issues_created_date.get(i));
                ps.setString(7, issues_due_date.get(i));
                ps.setString(8, issues_labels.get(i));

                ps.executeUpdate();
//                System.out.println("post");
            }
        } catch (SQLException ex) {
            Logger.getLogger(AdminDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }

    public int syncIssuesGitCheckUpdate(String project_id, String token) {
        int n = 0;
        Vector<Issues> IssuesList = new Vector<>();
        AdminDao dao = new AdminDao();
        String sql = "select * from spm_database.issue;";
        int checkDatabase = dao.getTotalIssues();
        try {

            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                Issues issue = new Issues();
                issue.setIssue_id(rs.getString("issue_id"));
                issue.setAssignee_id(rs.getString("assignee_id"));
                issue.setIssue_title(rs.getString("issue_title"));
                issue.setDescription(rs.getString("description"));
                issue.setGitlab_id(rs.getString("gitlab_id"));
                issue.setGitlab_url(rs.getString("gitlab_url"));
                issue.setCreated_date(rs.getString("created_date"));
                issue.setDue_date(rs.getString("due_date"));
                issue.setTeam_id(rs.getString("class_id"));
                issue.setTeam_id(rs.getString("team_id"));
                issue.setMilestone_id(rs.getString("milestone_id"));
                issue.setFunction_ids(rs.getString("function_id"));
                issue.setLabels(rs.getString("labels"));
                issue.setStatus(rs.getString("status"));
                IssuesList.add(issue);
//                System.out.println(IssuesList);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        //
        Vector<String> issues_iids = new Vector();
        Vector<String> issues_titles = new Vector();
        Vector<String> issues_descriptions = new Vector();
        Vector<String> issues_gitlab_id = new Vector();
        Vector<String> issues_gitlab_url = new Vector();
        Vector<String> issues_created_date = new Vector();
        Vector<String> issues_due_date = new Vector();
        Vector<String> issues_team_id = new Vector();
        Vector<String> issues_milestone_id = new Vector();
        Vector<String> issues_function_ids = new Vector();
        Vector<String> issues_labels = new Vector();
        Vector<String> issues_status = new Vector();
        String keys = "page";
//        Vector<String> values = new Vector<>();
        for (int j = 10; j > 0; --j) {
            int warring = 0;
            String values = String.valueOf(j);
            //get Git to json
            JSONArray jsons = new JSONArray();
            jsons = API.getJsonArrayGet("projects", project_id, "issues", keys, values, token);
            if (jsons != null) {
                for (int i = 0; i < jsons.length(); i++) {
                    JSONObject json = jsons.getJSONObject(i);

                    issues_iids.add(json.get("iid").toString().trim());
                    issues_titles.add(json.get("title").toString().trim());
                    issues_descriptions.add(json.get("description").toString().trim());
                    issues_gitlab_id.add(json.get("project_id").toString().trim());
                    issues_gitlab_url.add(json.get("web_url").toString().trim());
                    issues_created_date.add(json.get("created_at").toString().trim().substring(0, 10));
                    issues_due_date.add(json.get("updated_at").toString().trim().substring(0, 10));
//                issues_team_id.add(json.get("authorid").toString().trim());
//                issues_milestone_id.add(json.get("milestone_id").toString().trim());
//                issues_function_ids.add(json.get("function_ids").toString().trim());
                    issues_labels.add(json.get("labels").toString().trim());
                    issues_status.add(json.get("state").toString().trim());
                }

            }
        }
//      check
//        for (int i = 0; i < issues_iids.size(); i++) {
////            System.out.println(issues_iids.get(i));
////            System.out.println(issues_titles.get(i));
////            System.out.println(issues_descriptions.get(i));
////            System.out.println(issues_gitlab_id.get(i));
////            System.out.println(issues_gitlab_url.get(i));
////            System.out.println(issues_created_date.get(i));
////            System.out.println(issues_labels.get(i).contains("Doing"));
//            if (issues_labels.get(i).contains("Doing")) {
//                System.out.println(issues_labels.get(i));
//            }
//        }
        UserDao userDao = new UserDao();
        IssueDAO idao = new IssueDAO();
        ClassDao classDao = new ClassDao();
        MilestoneDao milesDao = new MilestoneDao();
        FunctionDao funcDao = new FunctionDao();
        List<User> listUser = userDao.getAllUser();
        List<Team> listTeam = dao.getAllTeam();
        List<Class> listClass = classDao.getAllListClass1();
        List<Milestone> listMilestone = milesDao.getAllMilestone();
        List<Function> listFunction = funcDao.getAllFunction1();
        //put DateBase
        String stauts = "1";
        String labels = "0";
        int k = 0;
        int h = 1;
        int t = 0;
        int c = 0;
        int m = 0;
        int f = 0;
        try {
            for (Issues issues : IssuesList) {
                for (int i = 0; i < issues_iids.size(); i++) {
                    if (issues.getIssue_id().equalsIgnoreCase(issues_iids.get(i))) {
//                    System.out.println(issues.getIssue_id());
//                        System.out.println("oke");
                        String SqlPut = "UPDATE `spm_database`.`issue`\n"
                                + "SET\n"
                                + "`issue_title` = ?,\n"
                                + "`description` = ?,\n"
                                + "`gitlab_id` = ?,\n"
                                + "`gitlab_url` = ?,\n"
                                + "`created_date` = ? ,\n"
                                + "`due_date` = ?,\n"
                                + "`labels` = ?,\n"
                                + "`status` = ?\n"
                                + "WHERE `issue_id` = ?;";

                        ps = conn.prepareStatement(SqlPut);
                        ps.setString(1, issues_titles.get(i));
                        ps.setString(2, issues_descriptions.get(i));
                        ps.setString(3, issues_gitlab_id.get(i));
                        ps.setString(4, issues_gitlab_url.get(i));
                        ps.setString(5, issues_created_date.get(i));
                        ps.setString(6, issues_due_date.get(i));
                        if (issues_labels.get(i).contains("Doing")) {
                            labels = "0";
                            ps.setString(7, labels);
                        }
                        if (issues_labels.get(i).contains("Done")) {
                            labels = "1";
                            ps.setString(7, labels);
                        }
                        if (issues_labels.get(i).contains("Q&A")) {
                            labels = "2";
                            ps.setString(7, labels);
                        }
                        if (issues_labels.get(i).contains("Task")) {
                            labels = "3";
                            ps.setString(7, labels);
                        }
                        ps.setString(8, issues_iids.get(i));
                        if (issues_status.get(i).equals("closed")) {
                            stauts = "1";
                            ps.setString(9, stauts);
                        }
                        if (issues_status.get(i).equals("opened")) {
                            stauts = "0";
                            ps.setString(9, stauts);
                        }
                        ps.executeUpdate();
//                        System.out.println("put");
                    }
//                    int issuesIDNew = Integer.parseInt(issues_iids.get(i));
                    if ((checkDatabase) < i) {
                        System.out.println(i);
                        System.out.println("check");
                        String SqlPost = "INSERT INTO `spm_database`.`issue`\n"
                                + "(`issue_id`,\n"
                                + "`assignee_id`,\n"
                                + "`assigneer`,\n"
                                + "`issue_title`,\n"
                                + "`description`,\n"
                                + "`gitlab_id`,\n"
                                + "`gitlab_url`,\n"
                                + "`created_date`,\n"
                                + "`due_date`,\n"
                                + "`class_id`,\n"
                                + "`team_id`,\n"
                                + "`milestone_id`,\n"
                                + "`function_id`,\n"
                                + "`labels`,\n"
                                + "`status`)"
                                + "VALUES\n"
                                + "(?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?,\n"
                                + "?);";

                        try {
                        } catch (Exception ex) {
                            Logger.getLogger(AdminDao.class.getName()).log(Level.SEVERE, null, ex);
                        }
                        ps = conn.prepareStatement(SqlPost);
                        ps.setString(1, issues_iids.get(i));
                        for (int j = 0; j < listUser.size(); j++) {
                            if (k == 5) {
                                k = 0;
                            }
                            ps.setString(2, listUser.get(k).getUserID());
                            k++;
                            break;
                        }
                        for (int j = 0; j < listUser.size(); j++) {
                            if (h == 5) {
                                h = 0;
                            }
                            ps.setString(3, listUser.get(h).getUserID());
                            h++;
                            break;
                        }
                        ps.setString(4, issues_titles.get(i));
                        ps.setString(5, issues_descriptions.get(i));
                        ps.setString(6, issues_gitlab_id.get(i));
                        ps.setString(7, issues_gitlab_url.get(i));
                        ps.setString(8, issues_created_date.get(i));
                        ps.setString(9, issues_due_date.get(i));
                        for (int j = 0; j < listClass.size(); j++) {
                            if (c == 8) {
                                c = 0;
                            }
                            ps.setString(10, listClass.get(t).getClassID());
                            c++;
                            break;
                        }
                        for (int j = 0; j < listTeam.size(); j++) {
                            if (t == 4) {
                                t = 0;
                            }
                            ps.setInt(11, listTeam.get(t).getTeam_id());
                            t++;
                            break;
                        }
                        for (int j = 0; j < listMilestone.size(); j++) {
                            if (m == 3) {
                                m = 0;
                            }
                            ps.setInt(12, listMilestone.get(m).getId());
                            m++;
                            break;
                        }
                        for (int j = 0; j < listFunction.size(); j++) {
                            if (f == 8) {
                                f = 0;
                            }
                            ps.setInt(13, listFunction.get(f).getId());
                            f++;
                            break;
                        }
                        if (issues_labels.get(i).contains("Doing")) {
                            labels = "0";
                            ps.setString(14, labels);
                        } else if (issues_labels.get(i).contains("Done")) {
                            labels = "1";
                            ps.setString(14, labels);
                        } else if (issues_labels.get(i).contains("Q&A")) {
                            labels = "2";
                            ps.setString(14, labels);
                        } else if (issues_labels.get(i).contains("Task")) {
                            labels = "3";
                            ps.setString(14, labels);
                        } else if (issues_labels.get(i).contains("")) {
                            labels = "1";
                            ps.setString(14, labels);
                        }
                        if (issues_status.get(i).equals("closed")) {
                            stauts = "0";
                            ps.setString(15, stauts);
                        } else if (issues_status.get(i).equals("opened")) {
                            stauts = "1";
                            ps.setString(15, stauts);
                        }
                        ps.executeUpdate();
//                System.out.println("post");
                    }

                }
            }

        } catch (SQLException ex) {
            Logger.getLogger(AdminDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }

    public List<Team> getAllTeam() {
        String sql = "select * from team";
        List<Team> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Team(rs.getInt(1),
                        rs.getInt(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
<<<<<<< HEAD
                        rs.getInt(7)));
=======
                        rs.getString(7),
                        rs.getInt(8)));
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void addSubjectSetting(String subjID, String settingid, String typeid, String title,
            String value, String order, String status) {
        String query = " INSERT INTO `spm_database`.`subject_setting`\n"
                + "(`subject_id`,\n"
                + "`setting_id`,\n"
                + "`type_id`,\n"
                + "`setting_title`,\n"
                + "`setting_value`,\n"
                + "`display_order`,\n"
                + "`status`)\n"
                + "VALUES\n"
                + "(?,\n"
                + "?,\n"
                + "?,\n"
                + "?,\n"
                + "?,\n"
                + "?,\n"
                + "?);";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, subjID);
            ps.setString(2, settingid);
            ps.setString(3, typeid);
            ps.setString(4, title);
            ps.setString(5, value);
            ps.setString(6, order);
            ps.setString(7, status);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    // Class User //
    public static void main(String[] args) {
        AdminDao dao = new AdminDao();
<<<<<<< HEAD
         List<Issues> list = new ArrayList<>();
list =dao.getAllIssue();
        for (Issues i : list) {
            System.out.println(i);
        }
//       dao.addIssue("HE150002", "Code", "Coding", 999, "haha", 2001-01-01, 2002-02-02, 2, 12, 132, "Doing", 1);
=======
//  
//        int n;
//        List<SubjectSetting> list = dao.getAllSubjectSetting();
//        String typeid = "";
//        String settingid = "2";
        List<Setting> list = dao.getAllSetting();
        for (Setting setting : list) {
            System.out.println(list);
        }
//        System.out.println(typeid);
//        for (SubjectSetting o : list) {
//            System.out.println(o);
//        }
>>>>>>> fe97544f977c6b60debee69de4a3a5b2bb408cb5
//        Iteration d = dao.getIterationByID(1);
//        System.out.println(d);

//        Setting s = new Setting();
//        dao.updatetCriteria("iter2", "0.5", "0.2", "5", "10", "0", 1);
//        System.out.println(s);
//        System.out.println(dao.syncIssuesGit("36006703", "glpat-spzc-6MZcxrvygH6_FC1"));
//        System.out.println(dao.syncIssuesGitCheckUpdate("36006703", "glpat-spzc-6MZcxrvygH6_FC1"));
        
        
//        System.out.println(dao.getAllSubjectSettingAllbyID("1"));
    }
}
