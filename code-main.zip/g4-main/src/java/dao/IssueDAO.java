/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import controller.common.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Issues;

/**
 *
 * @author 84337
 */
public class IssueDAO extends DBContext {

    Connection conn = null;        //ket noi voi sql sever
    PreparedStatement ps = null;   //nem cau lenh query sang sql sever
    ResultSet rs = null;
    
     public List<Issues> getAllIssue() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i join user u join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 1";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
 public List<Issues> IssueStatus0() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 0";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Issues> IssueAllStatus() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id";
               
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> IssueStatus1() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 1";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Issues> SortIssueAsscByAssignee() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by u.full_name asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> SortIssueAsscByAssignee4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id =?"
                + "                order by u.full_name asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> SortIssueAscByTeam() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by team_id asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortIssueTitleDesc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by issue_title desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortIssueTitleDesc4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id = ?"
                + "                order by issue_title desc ";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortIssueTitleAsc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by issue_title asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortIssueTitleAsc4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id =?"
                + "                order by issue_title asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortDueDateAsc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.due_date asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortDueDateAsc4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id =?"
                + "                order by i.due_date asc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortLableDesc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.labels desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortLableDesc4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id =?"
                + "                order by i.labels desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortLableAsc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.labels";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortLableAsc4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id = ? "
                + "                order by i.labels";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortDueDateDesc() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by i.due_date desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> sortDueDateDesc4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id = ?"
                + "                order by i.due_date desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> getAllIssueTeam() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,i.created_date,i.due_date,t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i join user u join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
     public List<Issues> SortIssueDescByAssignee() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by u.full_name desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> SortIssueDescByAssignee4S(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1 and t.team_id =?"
                + "                order by u.full_name desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
 public List<Issues> SortIssueDescByTeam() {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "                from issue i join user u join team t\n"
                + "                on i.assignee_id = u.user_id\n"
                + "                and t.team_id = i.team_id\n"
                + "                where i.status = 1"
                + "                order by team_id desc";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
  public void addIssue(String assignee_id, String issue_title, String description, int gitlab_id, String gitlab_url, String created_date, String due_date,
            int team_id, int milestone_id, int function_ids, int labels, int status) {
        String query = "insert into issue( assignee_id, issue_title, description, gitlab_id, gitlab_url, created_date, due_date, team_id, milestone_id, function_ids, labels, status)  \n"
                + "values(?, ?, ?, ?, ?, ?, ? , ?, ?, ?, ?, ? );";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, assignee_id);
            ps.setString(2, issue_title);
            ps.setString(3, description);
            ps.setInt(4, gitlab_id);
            ps.setString(5, gitlab_url);
            ps.setString(6, created_date);
            ps.setString(7, due_date);
            ps.setInt(8, team_id);
            ps.setInt(9, milestone_id);
            ps.setInt(10, function_ids);
            ps.setInt(11, labels);
            ps.setInt(12, status);
//            ps.setString(11, description);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
      public Issues getTeamIssueByID(String id) {
        String query = "select team_id from issue where assignee_id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Issues(rs.getString(1));
                       
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
       public List<Issues> getAllIssueForStudent(String team_id) {
        String sql = "select i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i join user u join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 1 and t.team_id = ? ";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, team_id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
  public List<Issues> searchIssueForStudent(String txtSearch, String team_id) {
        List<Issues> list = new ArrayList<>();
        String query = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where issue_title like ? or u.full_name like ? or i.assignee_id like ?\n"
                + "or i.due_date like ? or i.milestone_id like ? or i.description like ? or i.labels  like ? or i.function_ids like ?"
                + "and i.status = 1 and t.team_id = ?";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
            ps.setString(7, "%" + txtSearch + "%");
            ps.setString(8, "%" + txtSearch + "%");
            ps.setString(9, team_id);

//            ps.setInt(7, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> searchIssueTeam(String tid) {
        List<Issues> list = new ArrayList<>();
        String query = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where t.team_id = ? and  i.status = 1";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, tid );

//            ps.setInt(7, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

}
