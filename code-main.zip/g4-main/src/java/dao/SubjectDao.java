/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.common.DBContext;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ClassUser;
import model.Issues;
import model.Subject;
import model.SubjectSetting;

/**
 *
 * @author My PC
 */
public class SubjectDao extends DBContext {

    Connection conn = null;        //ket noi voi sql sever
    PreparedStatement ps = null;   //nem cau lenh query sang sql sever
    ResultSet rs = null;           //nhan ket qua tra ve

    public List<Subject> getAllSubject(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id limit ?, 7;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 7);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
 public List<SubjectSetting> searchSS(String txtSearch) {
         List<SubjectSetting> list = new ArrayList<>();
        String query = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 \n"
                + "and  st.setting_title like ? or sb.subject_name like ? or st.setting_type like ? or ss.setting_title like ? or ss.setting_value like ? \n"
                + "order by ss.subject_setting_id ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
//            ps.setString(6, "%" + txtSearch + "%");
//            ps.setInt(7, (index - 1) * 5);

            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public SubjectSetting getSubjectSettingByID(String id) {
        String query = "select status from subject_setting where  subject_setting_id = ?; ";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new SubjectSetting(rs.getString(1))    ;
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public List<SubjectSetting> SubjectSettingByStatus1() {
               String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 \n"
                + "\n"
                + "order by ss.subject_setting_id ;";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<SubjectSetting> SubjectSettingByStatus0() {
              String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 0 \n"
                + "\n"
                + "order by ss.subject_setting_id ;";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void changeStatusSubjectSetting(String id) throws Exception {

        String sql = "update subject_setting set status =  ?  where setting_id = ?;";
        String status = "1";
        SubjectSetting sb = new SubjectSetting();
        sb = getSubjectSettingByID(id);
        if (sb.getStatus().compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, status);
            st.setString(2, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public void changeStatus(String id) throws Exception {

        String sql = "update subject set status = ? where subject_id = ?;";
        String status = "1";
        Subject sb = new Subject();
        sb = getSubjectByID(id);
        if (sb.getSubject_status().compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, status);
            st.setString(2, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public Subject getSubjectByID(String id) {
        String query = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id where  subject_id = ?; ";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }

    public int getTotalSubject() {
        String query = "select count(*) from subject";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return 0;
    }

    public List<Subject> search(String txtSearch) {
        List<Subject> list = new ArrayList<>();
        String query = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id where subject_id like ? or subject_code like ? or subject_name like ? ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByID(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id ORDER BY subject_id limit ?, 7 ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByCode(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id ORDER BY subject_code limit ?, 7 ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByName(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id ORDER BY subject_name limit ?, 7 ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByStatus1(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status  from user iner join subject on user_id = author_id where subject.status = 1 ORDER BY subject_id limit ?, 7 ";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByStatus0(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status  from user iner join subject on user_id = author_id where subject.status = 0 ORDER BY subject_id limit ?, 7 ";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    
    public void EditIssue( String issue_title, String description, String gitlab_id, String due_date,     String labels, String status, String id) {
        String sql = "update  issue set issue_title = ? , description = ? ,  gitlab_id = ? , due_date  = STR_TO_DATE(?, '%d-%m-%Y'),labels = ?,status=? where issue_id = ?;";

        try {
            PreparedStatement ps = getConnection().prepareStatement(sql);
            ps.setString(1, issue_title);

            ps.setString(2, description);
            ps.setString(3, gitlab_id);
//            ps.setString(4, avatar);
            ps.setString(4, due_date);
            ps.setString(5, labels);
            ps.setString(6, status);
            ps.setString(7, id);

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

   

    public List<ClassUser> searchClassUser(String txtSearch) {
        List<ClassUser> list = new ArrayList<>();
        String query = "select * from class_user where dropout_date like ? or class_id like ? or team_id like ? or user_id like ? or user_notes like ? or ongoing_eval like ? or final_pres_eval like ? or final_topic_eval like ? ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
            ps.setString(7, "%" + txtSearch + "%");
            ps.setString(8, "%" + txtSearch + "%");
//            ps.setString(9, "%" + txtSearch + "%");
//            ps.setInt(7, (index - 1) * 5);

            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new ClassUser(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    

   

    public void EditSubject(String code, String name, String author, String des, String status, String id) throws Exception {
        String sql = "update spm_database.subject set subject_code = ?, subject_name = ?, author_id = ?, description = ?,  status = ? where subject_id = ? ;";

        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            //............
            st.setString(1, code);
            st.setString(2, name);
            st.setString(3, author);
            st.setString(4, des);
            st.setString(5, status);
            st.setString(6, id);
            ///...................
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    public List<Subject> getSortSubjectByAuthor(int index, String author) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id and author_id like ? order by subject_id limit ?, 7 ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, author);
            ps.setInt(2, (index - 1) * 7);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByIDASC(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, description, subject.status from user iner join subject on user_id = author_id ORDER BY subject_id limit ?, 7 ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 7);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Subject> getSortSubjectByIDDESC(int index) {
        String sql = "select subject_id, subject_code, subject_name, full_name, subject.status from spm_database.user join spm_database.subject where user_id = author_id ORDER BY subject_id desc limit ?, 7 ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (index - 1) * 7);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public void AddSubject(Subject p) throws Exception {
        String sql = "insert into subject(subject_code, subject_name, author_id, description, status) values(?, ?, ?, ?, ?);";

        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, p.getSubject_code());
            st.setString(2, p.getSubject_name());
            st.setString(3, p.getSubject_author());
            st.setString(4, p.getDescription());
            st.setString(5, p.getSubject_status());
            ///...................
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
    public List<Subject> getAllSubject() {
        String sql = "select * from spm_database.subject ;";
        List<Subject> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Subject(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
public Issues getIssueByID(String id) {
        String query = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,i.created_date,DATE_FORMAT(i.due_date, \"%d-%m-%Y\")  ,t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.issue_id = ?";
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }


    public List<Issues> searchIssue(String txtSearch) {
        List<Issues> list = new ArrayList<>();
        String query = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where issue_title like ? or u.full_name like ? or i.assignee_id like ?\n"
                + "or i.due_date like ? or i.milestone_id like ? or i.description like ? or i.labels  like ? or i.function_ids like ?"
                + "and i.status = 1";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
            ps.setString(7, "%" + txtSearch + "%");
            ps.setString(8, "%" + txtSearch + "%");
//            ps.setString(9, "%" + txtSearch + "%");

//            ps.setInt(7, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> searchIssueTeam(String tid) {
        List<Issues> list = new ArrayList<>();
        String query = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where t.team_id = ? and  i.status = 1";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, tid );

//            ps.setInt(7, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }


    public void changeStatusIssue(String id) throws Exception {

        String sql = "update issue set status =  ?  where issue_id = ?;";
        String status = "1";
        Issues is = new Issues();
        is = getIssueByID(id);
        if (is.getStatus().compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, status);
            st.setString(2, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }


    public List<Issues> IssueStatus0() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 0";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<Issues> IssueAllStatus() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id";
               
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public List<Issues> IssueStatus1() {
        String sql = "select distinct i.issue_id, i.assignee_id, u.full_name, i.issue_title, i.description,i.gitlab_id,i.gitlab_url,DATE_FORMAT(i.created_date, \"%d-%m-%Y\"),DATE_FORMAT(i.due_date, \"%d-%m-%Y\"),t.team_id,i.milestone_id,i.function_ids,i.labels,i.status \n"
                + "from issue i inner join user u inner join team t\n"
                + "on i.assignee_id = u.user_id\n"
                + "and t.team_id = i.team_id\n"
                + "where i.status = 1";
        List<Issues> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
//            ps.setInt(1, (index - 1) * 5);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new Issues(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10),
                        rs.getString(11),
                        rs.getString(12),
                        rs.getString(13),
                        rs.getString(14)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
     public void changeStatusSubjectSetting(String status, String id) throws Exception {

        String sql = "update subject_setting set status =  ? where subject_setting_id = ?";
         
       
       
        if (status.compareTo("1") == 0) {
            status = "0";
        } else {
            status = "1";
        }
        try {
            PreparedStatement st = getConnection().prepareStatement(sql);
            st.setString(1, status);
            st.setString(2, id);
            st.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
     public List<SubjectSetting> SubjectSettingBySubject(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and ss.subject_id =? \n"
                + "\n"
                + "order by ss.subject_setting_id ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<SubjectSetting> SubjectSettingBySubjectForAuth(String id, String userID) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and ss.subject_id =? \n"
                + " and sb.author_id= ?\n"
                + "order by ss.subject_setting_id ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setString(2, userID);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    public List<SubjectSetting> SubjectSettingByStatus0ForAth(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 0 and sb.author_id=? \n"
                + "order by ss.subject_setting_id ; ";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
     public List<SubjectSetting> SubjectSettingByStatus1ForAuth(String id) {
        String sql = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and  sb.author_id= ?\n"
                + "\n"
                + "order by ss.subject_setting_id ;";
        List<SubjectSetting> list = new ArrayList();
        try {
            conn = new DBContext().getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
     public List<SubjectSetting> searchSSForAuth(String id, String txtSearch) {
        List<SubjectSetting> list = new ArrayList<>();
        String query = "select ss.subject_setting_id ,ss.subject_id, sb.subject_name,ss.type_id, st.setting_type,  sb.author_id, ss.setting_title, ss.setting_value,ss.display_order, ss.status \n"
                + "from subject_setting ss \n"
                + " join subject sb join setting st\n"
                + "on ss.subject_id =sb.subject_id\n"
                + "and ss.setting_id = st.setting_id\n"
                + "where ss.status = 1 and sb.author_id = ?\n"
                + "and  st.setting_title like ? or sb.subject_name like ? or st.setting_type like ? or ss.setting_title like ? or ss.setting_value like ? \n"
                + "order by ss.subject_setting_id ;";
        try {
            conn = new DBContext().getConnection();//mo ket noi voi sql
            ps = conn.prepareStatement(query);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + txtSearch + "%");
            ps.setString(3, "%" + txtSearch + "%");
            ps.setString(4, "%" + txtSearch + "%");
            ps.setString(5, "%" + txtSearch + "%");
            ps.setString(6, "%" + txtSearch + "%");
//            ps.setInt(7, (index - 1) * 5);

            rs = ps.executeQuery();
            while (rs.next()) {
                list.add(new SubjectSetting(rs.getString(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getString(6),
                        rs.getString(7),
                        rs.getString(8),
                        rs.getString(9),
                        rs.getString(10)));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }}



 