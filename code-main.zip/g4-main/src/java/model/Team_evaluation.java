/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author My PC
 */
public class Team_evaluation {

    private String team_eval_id;
    private String evaluation_id;
    private String class_code;
    private String subject_name;
    private String criteria_id;
    private String criteria_name;
    private String team_id;
    private String team_name;
    private String iter_name;
    private String grade;
    private String note;

    public Team_evaluation() {
    }

    public Team_evaluation(String team_eval_id, String evaluation_id, String criteria_id, String team_id, String grade, String note) {
        this.team_eval_id = team_eval_id;
        this.evaluation_id = evaluation_id;
        this.criteria_id = criteria_id;
        this.team_id = team_id;
        this.grade = grade;
        this.note = note;
    }

    
    public Team_evaluation(String team_eval_id, String evaluation_id, String class_code, String subject_name, String team_name, String iter_name, String grade, String note) {
        this.team_eval_id = team_eval_id;
        this.evaluation_id = evaluation_id;
        this.class_code = class_code;
        this.subject_name = subject_name;
        this.team_name = team_name;
        this.iter_name = iter_name;
        this.grade = grade;
        this.note = note;
    }
    public Team_evaluation(String team_eval_id, String evaluation_id, String class_code, String subject_name, String team_name, String criteria_name, String iter_name, String grade, String note) {
        this.team_eval_id = team_eval_id;
        this.evaluation_id = evaluation_id;
        this.class_code = class_code;
        this.subject_name = subject_name;
        this.team_name = team_name;
        this.criteria_name = criteria_name;
        this.iter_name = iter_name;
        this.grade = grade;
        this.note = note;
    }


    public String getTeam_eval_id() {
        return team_eval_id;
    }

    public void setTeam_eval_id(String team_eval_id) {
        this.team_eval_id = team_eval_id;
    }

    public String getClass_code() {
        return class_code;
    }

    public void setClass_code(String class_code) {
        this.class_code = class_code;
    }

    public String getSubject_name() {
        return subject_name;
    }

    public void setSubject_name(String subject_name) {
        this.subject_name = subject_name;
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getEvaluation_id() {
        return evaluation_id;
    }

    public void setEvaluation_id(String evaluation_id) {
        this.evaluation_id = evaluation_id;
    }

    public String getCriteria_id() {
        return criteria_id;
    }

    public void setCriteria_id(String criteria_id) {
        this.criteria_id = criteria_id;
    }

    public String getCriteria_name() {
        return criteria_name;
    }

    public void setCriteria_name(String criteria_name) {
        this.criteria_name = criteria_name;
    }

    public String getTeam_id() {
        return team_id;
    }

    public void setTeam_id(String team_id) {
        this.team_id = team_id;
    }

    public String getIter_name() {
        return iter_name;
    }

    public void setIter_name(String iter_name) {
        this.iter_name = iter_name;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    @Override
    public String toString() {
        return "Team_evaluation{" + "team_eval_id=" + team_eval_id + ", evaluation_id=" + evaluation_id + ", class_code=" + class_code + ", subject_name=" + subject_name + ", team_name=" + team_name + ", iter_name=" + iter_name + ", grade=" + grade + ", note=" + note + '}';
    }


}
