/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author My PC
 */
public class Feature {
    private String feature_id;
    private String feature_class;
    private String team_name;    
    private String feature_name;
    private String feature_description;
    private String feature_status;

    public Feature() {
    }

    public Feature(String feature_id, String team_name) {
        this.feature_id = feature_id;
        this.team_name = team_name;
    }
    
    
    public Feature(String feature_id, String feature_class, String team_name, String feature_name, String feature_description, String feature_status) {
        this.feature_id = feature_id;
        this.feature_class = feature_class;
        this.team_name = team_name;
        this.feature_name = feature_name;
        this.feature_description = feature_description;
        this.feature_status = feature_status;
    }

    public Feature(String team_name, String feature_name, String feature_description, String feature_status) {
        this.team_name = team_name;
        this.feature_name = feature_name;
        this.feature_description = feature_description;
        this.feature_status = feature_status;
    }

    public String getFeature_id() {
        return feature_id;
    }

    public void setFeature_id(String feature_id) {
        this.feature_id = feature_id;
    }

    public String getFeature_class() {
        return feature_class;
    }

    public void setFeature_class(String feature_class) {
        this.feature_class = feature_class;
    }

    public String getTeam_name() {
        return team_name;
    }

    public void setTeam_name(String team_name) {
        this.team_name = team_name;
    }

    public String getFeature_name() {
        return feature_name;
    }

    public void setFeature_name(String feature_name) {
        this.feature_name = feature_name;
    }

    public String getFeature_description() {
        return feature_description;
    }

    public void setFeature_description(String feature_description) {
        this.feature_description = feature_description;
    }

    public String getFeature_status() {
        return feature_status;
    }

    public void setFeature_status(String feature_status) {
        this.feature_status = feature_status;
    }

    @Override
    public String toString() {
        return "Feature{" + "feature_id=" + feature_id + ", feature_class=" + feature_class + ", team_name=" + team_name + ", feature_name=" + feature_name + ", feature_description=" + feature_description + ", feature_status=" + feature_status + '}';
    }

    
    
}
