/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author PC PHUC
 */
public class SubjectSetting {

    private String id;
    private String setting_id;
    private String subject_id;
    private String subject_name;
    private String type_id;
    private String setting_type;
    private String author_id;
    private String title;
    private String value;
    private String order;
    private String status;

    public SubjectSetting() {

    }

    public SubjectSetting(String status) {
        this.status = status;

       
    }
    
   

    public SubjectSetting(String id, String subject_id, String subject_name, String type_id, String setting_type, String author_id, String title, String value, String order, String status) {
        this.id = id;
        this.subject_id = subject_id;
        this.subject_name = subject_name;
        this.type_id = type_id;
        this.setting_type = setting_type;
        this.author_id = author_id;
        this.title = title;
        this.value = value;
        this.order = order;
        this.status = status;
    }
    
    public SubjectSetting(String id, String setting_id, String subject_id, String subject_name, String type_id, String setting_type, String author_id, String title, String value, String order, String status) {
        this.id = id;
        this.setting_id = setting_id;
        this.subject_id = subject_id;
        this.subject_name = subject_name;
        this.type_id = type_id;
        this.setting_type = setting_type;
        this.author_id = author_id;
        this.title = title;
        this.value = value;
        this.order = order;
        this.status = status;
    }

    
    

    public SubjectSetting(String id, String subject_id, String type_id, String title, String value, String order, String status) {
        this.id = id;
        this.subject_id = subject_id;
        this.type_id = type_id;
        this.title = title;
        this.value = value;
        this.order = order;
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSubject_id() {
        return subject_id;
    }

    public void setSubject_id(String subject_id) {
        this.subject_id = subject_id;
    }

    public String getType_id() {
        return type_id;
    }

    public void setType_id(String type_id) {
        this.type_id = type_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getOrder() {
        return order;
    }

    public void setOrder(String order) {
        this.order = order;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSubject_name() {
        return subject_name;
    }

    public void setSubject_name(String subject_name) {
        this.subject_name = subject_name;
    }

    public String getAuthor_id() {
        return author_id;
    }

    public void setAuthor_id(String author_id) {
        this.author_id = author_id;
    }

    public String getSetting_type() {
        return setting_type;
    }

    public void setSetting_type(String setting_type) {
        this.setting_type = setting_type;
    }

    public String getSetting_id() {
        return setting_id;
    }

    public void setSetting_id(String setting_id) {
        this.setting_id = setting_id;
    }

    @Override
    public String toString() {
        return "SubjectSetting{" + "id=" + id + ", setting_id=" + setting_id + ", subject_id=" + subject_id + ", subject_name=" + subject_name + ", type_id=" + type_id + ", setting_type=" + setting_type + ", author_id=" + author_id + ", title=" + title + ", value=" + value + ", order=" + order + ", status=" + status + '}';
    }

   

}
